<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Detalle_compra;
use App\Models\Empresa;
use App\Models\Familia;
use App\Models\General;
use App\Models\Logs;
use App\Models\Menu;
use App\Models\Opciones;
use App\Models\Orden_compra;
use App\Models\PDFBufeo;
use App\Models\Persona;
use App\Models\Productos;
use App\Models\Proveedores;
use App\Models\Submenu;
use App\Models\Tipo_afectacion;
use App\Models\Tipo_documento;
use App\Models\Tipo_pago;
use App\Models\User;
use App\Service\CalcularMontosVenta;
use Carbon\Carbon;
use Codedge\Fpdf\Fpdf\Fpdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
class LogisticaController extends Controller
{
    private $submenu;
    private $logs;
    private $general;
    private $almacen;
    private $productos;
    private $categorias;
    private $proveedores;
    private $tipo_venta;
    private $tipo_pago;
    private $ordenCompra;
    private $ordenCompraDetalle;
    private $empresa;
    public function __construct()
    {
        $this->submenu = new Submenu();
        $this->logs = new Logs();
        $this->general = new General();
        $this->productos = new Productos();
        $this->categorias = new Categoria();
        $this->proveedores = new Proveedores();
        $this->tipo_pago = new Tipo_pago();
        $this->ordenCompra = new Orden_compra();
        $this->ordenCompraDetalle = new Detalle_compra();
        $this->empresa = new Empresa();
    }
    public function gestionar_productos()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("gestionar_productos");
            return view('logistica/gestionar_productos', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }
    public function compras()
    {
        try {
//            ESTE IF ES PARA VERIFICAR SI ESE ROL TIENE EL PERMISO PARA LA VISTA
            $opciones = $this->submenu->optiones_por_vista("compras");
            return view('logistica/compras', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }
    public function ordenCompraDetalle()
    {
        try {
            $id = $_GET['ordenCompra'] ?? null;
            if (!$id) {
                return redirect()->route('logistica.compras');
            }

            $orden_compra = DB::table('orden_compra as oc')
                ->join('proveedores as pv', 'pv.id_proveedores', '=', 'oc.id_proveedores')
                ->join('users as u', 'u.id_users', '=', 'oc.id_solicitante')
                ->leftJoin('tipo_pago as tp', 'tp.id_tipo_pago', '=', 'oc.id_tipo_pago')
                ->leftJoin('tiendas as t', 't.id_tienda', '=', 'oc.id_sucursal')
                ->leftJoin('empresa as e', 'e.id_empresa', '=', 't.id_empresa')
                ->leftJoin('almacen as al', 'al.id_almacen', '=', 'oc.id_almacen')
                ->select(
                    'oc.*',
                    'pv.proveedores_nombre', 'pv.proveedores_numero_documento',
                    'u.nombre_users',
                    'tp.tipo_pago_nombre',
                    't.tienda_nombre as sucursal_nombre',
                    'e.empresa_nombrecomercial', 'e.empresa_foto',
                    'al.almacen_nombre', 'al.almacen_direccion'
                )
                ->where('oc.id_orden_compra', $id)
                ->first();

            if (!$orden_compra) {
                return redirect()->route('logistica.compras');
            }

            $detalle_orden_compra = DB::table('orden_compra_detalle as ocd')
                ->join('productos as p', 'p.id_pro', '=', 'ocd.id_pro')
                ->select('ocd.*', 'p.pro_nombre', 'p.pro_codigo')
                ->where('ocd.id_orden_compra', $id)
                ->get();

            $subtotal = $detalle_orden_compra->sum('detalle_compra_total_pedido');
            $total    = $subtotal
                + (float) ($orden_compra->orden_compra_flete ?? 0)
                + (float) ($orden_compra->orden_compra_gastos_operativos ?? 0);

            $opciones = $this->submenu->optiones_por_vista("ordenCompraDetalle");

            return view('logistica/ordenCompraDetalle', compact(
                'opciones', 'orden_compra', 'detalle_orden_compra', 'subtotal', 'total'
            ));

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }
    public function stock_establecimiento()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("stock_establecimiento");
            return view('logistica/stock_establecimiento', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\"); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    public function stock_consolidado()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("stock_consolidado");
            return view('logistica/stock_consolidado', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\"); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    public function transferencias_stock()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("transferencias_stock");
            return view('logistica/transferencias', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\"); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    public function mercaderia_transito()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("mercaderia_transito");
            return view('logistica/mercaderia_transito', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\"); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    private function obtenerDatosMercaderiaTransito(Request $request): array
    {
        $idEmpresa  = $request->id_empresa  ?? null;
        $idSucursal = $request->id_sucursal ?? null;

        $compras = DB::table('orden_compra as oc')
            ->join('proveedores as pv', 'pv.id_proveedores', '=', 'oc.id_proveedores')
            ->leftJoin('sucursals as s', 's.id_sucursal', '=', 'oc.id_sucursal')
            ->select('oc.orden_compra_numero', 'oc.orden_compra_estado', 'oc.orden_compra_fecha',
                'oc.orden_compra_total', 'pv.proveedores_nombre', 's.sucursal_nombre')
            ->whereIn('oc.orden_compra_estado', ['pendiente', 'en_transito'])
            ->where('oc.orden_compra_activo', 1);

        if ($idSucursal) {
            $compras->where('oc.id_sucursal', $idSucursal);
        } elseif ($idEmpresa) {
            $compras->whereExists(fn($q) => $q->select(DB::raw(1))
                ->from('sucursals')->whereColumn('sucursals.id_sucursal', 'oc.id_sucursal')
                ->where('sucursals.id_empresa', $idEmpresa));
        } else {
            $compras->whereRaw('0 = 1');
        }

        $transferencias = DB::table('transferencias_stock as t')
            ->join('sucursals as so', 'so.id_sucursal', '=', 't.id_sucursal_origen')
            ->join('sucursals as sd', 'sd.id_sucursal', '=', 't.id_sucursal_destino')
            ->leftJoin('users as u', 'u.id_users', '=', 't.id_users')
            ->select('t.transferencia_numero', 't.transferencia_estado', 't.transferencia_fecha',
                't.transferencia_motivo', 'so.sucursal_nombre as origen_nombre',
                'sd.sucursal_nombre as destino_nombre', 'u.nombre_users')
            ->whereIn('t.transferencia_estado', ['pendiente', 'en_transito']);

        if ($idSucursal) {
            $transferencias->where(fn($q) => $q->where('t.id_sucursal_origen', $idSucursal)
                ->orWhere('t.id_sucursal_destino', $idSucursal));
        } elseif ($idEmpresa) {
            $transferencias->where(fn($q) => $q
                ->whereExists(fn($s) => $s->select(DB::raw(1))->from('sucursals')
                    ->whereColumn('sucursals.id_sucursal', 't.id_sucursal_origen')
                    ->where('sucursals.id_empresa', $idEmpresa))
                ->orWhereExists(fn($s) => $s->select(DB::raw(1))->from('sucursals')
                    ->whereColumn('sucursals.id_sucursal', 't.id_sucursal_destino')
                    ->where('sucursals.id_empresa', $idEmpresa)));
        } else {
            $transferencias->whereRaw('0 = 1');
        }

        return [
            'compras'        => $compras->orderByDesc('oc.orden_compra_fecha')->get(),
            'transferencias' => $transferencias->orderByDesc('t.transferencia_fecha')->get(),
        ];
    }

    public function mercaderiaTransitoPdf(Request $request)
    {
        try {
            $d   = $this->obtenerDatosMercaderiaTransito($request);
            $pdf = new PDFBufeo('L', 'mm', 'A4');
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(267, 8, 'REPORTE DE MERCADERÍA EN TRÁNSITO', 0, 1, 'C');
            $pdf->SetFont('Arial', '', 8);
            $pdf->Cell(267, 6, 'Generado: ' . now()->format('d/m/Y H:i'), 0, 1, 'R');

            // ── Órdenes de compra ──────────────────────────────
            $pdf->SetFont('Arial', 'B', 8);
            $pdf->SetFillColor(240, 240, 240);
            $pdf->Cell(267, 6, 'ÓRDENES DE COMPRA EN TRÁNSITO (' . $d['compras']->count() . ')', 1, 1, 'L', true);

            // Cabecera: 30+25+90+55+30+22+15 = 267
            $pdf->SetFillColor(70, 89, 110);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->Cell(30, 6, 'N° Orden',   1, 0, 'C', true);
            $pdf->Cell(25, 6, 'Fecha',       1, 0, 'C', true);
            $pdf->Cell(90, 6, 'Proveedor',   1, 0, 'C', true);
            $pdf->Cell(55, 6, 'Sucursal',    1, 0, 'C', true);
            $pdf->Cell(30, 6, 'Total',       1, 0, 'C', true);
            $pdf->Cell(22, 6, 'Estado',      1, 1, 'C', true);

            $pdf->SetTextColor(0, 0, 0);
            $pdf->SetFont('Arial', '', 7);
            $fill = false;
            foreach ($d['compras'] as $oc) {
                $pdf->SetFillColor($fill ? 245 : 255, $fill ? 245 : 255, $fill ? 245 : 255);
                $pdf->Cell(30, 5, $oc->orden_compra_numero ?? '-', 1, 0, 'C', true);
                $pdf->Cell(25, 5, date('d/m/Y', strtotime($oc->orden_compra_fecha)), 1, 0, 'C', true);
                $pdf->Cell(90, 5, $oc->proveedores_nombre, 1, 0, 'L', true);
                $pdf->Cell(55, 5, $oc->sucursal_nombre ?? '-', 1, 0, 'L', true);
                $pdf->Cell(30, 5, 'S/ ' . number_format($oc->orden_compra_total ?? 0, 2), 1, 0, 'R', true);
                $estado = $oc->orden_compra_estado === 'pendiente' ? 'Pendiente' : 'En Tránsito';
                $pdf->Cell(22, 5, $estado, 1, 1, 'C', true);
                $fill = !$fill;
            }

            if ($d['compras']->isEmpty()) {
                $pdf->Cell(252, 5, 'Sin órdenes de compra en tránsito.', 1, 1, 'C');
            }

            $pdf->Ln(4);

            // ── Transferencias ─────────────────────────────────
            $pdf->SetFont('Arial', 'B', 8);
            $pdf->SetFillColor(240, 240, 240);
            $pdf->Cell(267, 6, 'TRANSFERENCIAS EN TRÁNSITO (' . $d['transferencias']->count() . ')', 1, 1, 'L', true);

            // Cabecera: 30+25+70+70+40+17+15 = 267
            $pdf->SetFillColor(70, 89, 110);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->Cell(30, 6, 'N° Trans.',  1, 0, 'C', true);
            $pdf->Cell(25, 6, 'Fecha',      1, 0, 'C', true);
            $pdf->Cell(70, 6, 'Origen',     1, 0, 'C', true);
            $pdf->Cell(70, 6, 'Destino',    1, 0, 'C', true);
            $pdf->Cell(40, 6, 'Motivo',     1, 0, 'C', true);
            $pdf->Cell(17, 6, 'Estado',     1, 1, 'C', true);

            $pdf->SetTextColor(0, 0, 0);
            $pdf->SetFont('Arial', '', 7);
            $fill = false;
            foreach ($d['transferencias'] as $trf) {
                $pdf->SetFillColor($fill ? 245 : 255, $fill ? 245 : 255, $fill ? 245 : 255);
                $pdf->Cell(30, 5, $trf->transferencia_numero ?? '-', 1, 0, 'C', true);
                $pdf->Cell(25, 5, date('d/m/Y', strtotime($trf->transferencia_fecha)), 1, 0, 'C', true);
                $pdf->Cell(70, 5, $trf->origen_nombre, 1, 0, 'L', true);
                $pdf->Cell(70, 5, $trf->destino_nombre, 1, 0, 'L', true);
                $pdf->Cell(40, 5, $trf->transferencia_motivo ?? '-', 1, 0, 'L', true);
                $estado = $trf->transferencia_estado === 'pendiente' ? 'Pendiente' : 'En Tránsito';
                $pdf->Cell(17, 5, $estado, 1, 1, 'C', true);
                $fill = !$fill;
            }

            if ($d['transferencias']->isEmpty()) {
                $pdf->Cell(252, 5, 'Sin transferencias en tránsito.', 1, 1, 'C');
            }

            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="mercaderia_transito_' . date('Ymd_His') . '.pdf"');
            echo $pdf->Output('S', '');
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
        }
    }

    public function mercaderiaTransitoExcel(Request $request)
    {
        try {
            $d = $this->obtenerDatosMercaderiaTransito($request);
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();

            $navy  = 'FF46596E';
            $white = 'FFFFFFFF';
            $estiloH = [
                'font'      => ['bold' => true, 'color' => ['argb' => $white], 'size' => 8, 'name' => 'Arial'],
                'fill'      => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['argb' => $navy]],
                'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
            ];
            $estiloD = [
                'font'    => ['size' => 8, 'name' => 'Arial'],
                'borders' => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                               'color'       => ['argb' => 'FFD0D0D0']]],
            ];

            // ── Hoja 1: Compras ────────────────────────────────
            $sheet1 = $spreadsheet->getActiveSheet()->setTitle('Compras Tránsito');
            $row = 1;
            $h1 = ['A' => 'N° Orden', 'B' => 'Fecha', 'C' => 'Proveedor', 'D' => 'Sucursal', 'E' => 'Total', 'F' => 'Estado'];
            foreach ($h1 as $col => $h) $sheet1->setCellValue("{$col}{$row}", $h);
            $sheet1->getStyle("A{$row}:F{$row}")->applyFromArray($estiloH);
            $row++;
            foreach ($d['compras'] as $oc) {
                $sheet1->setCellValue("A{$row}", $oc->orden_compra_numero ?? '-');
                $sheet1->setCellValue("B{$row}", date('d/m/Y', strtotime($oc->orden_compra_fecha)));
                $sheet1->setCellValue("C{$row}", $oc->proveedores_nombre);
                $sheet1->setCellValue("D{$row}", $oc->sucursal_nombre ?? '-');
                $sheet1->setCellValue("E{$row}", (float)($oc->orden_compra_total ?? 0));
                $sheet1->getStyle("E{$row}")->getNumberFormat()->setFormatCode('"S/ "#,##0.00');
                $sheet1->setCellValue("F{$row}", $oc->orden_compra_estado === 'pendiente' ? 'Pendiente' : 'En Tránsito');
                $sheet1->getStyle("A{$row}:F{$row}")->applyFromArray($estiloD);
                $row++;
            }
            foreach (range('A', 'F') as $col) $sheet1->getColumnDimension($col)->setAutoSize(true);

            // ── Hoja 2: Transferencias ─────────────────────────
            $sheet2 = $spreadsheet->createSheet()->setTitle('Transferencias Tránsito');
            $row = 1;
            $h2 = ['A' => 'N° Trans.', 'B' => 'Fecha', 'C' => 'Origen', 'D' => 'Destino', 'E' => 'Motivo', 'F' => 'Estado'];
            foreach ($h2 as $col => $h) $sheet2->setCellValue("{$col}{$row}", $h);
            $sheet2->getStyle("A{$row}:F{$row}")->applyFromArray($estiloH);
            $row++;
            foreach ($d['transferencias'] as $trf) {
                $sheet2->setCellValue("A{$row}", $trf->transferencia_numero ?? '-');
                $sheet2->setCellValue("B{$row}", date('d/m/Y', strtotime($trf->transferencia_fecha)));
                $sheet2->setCellValue("C{$row}", $trf->origen_nombre);
                $sheet2->setCellValue("D{$row}", $trf->destino_nombre);
                $sheet2->setCellValue("E{$row}", $trf->transferencia_motivo ?? '-');
                $sheet2->setCellValue("F{$row}", $trf->transferencia_estado === 'pendiente' ? 'Pendiente' : 'En Tránsito');
                $sheet2->getStyle("A{$row}:F{$row}")->applyFromArray($estiloD);
                $row++;
            }
            foreach (range('A', 'F') as $col) $sheet2->getColumnDimension($col)->setAutoSize(true);

            $spreadsheet->setActiveSheetIndex(0);
            $nombreArchivo = 'mercaderia_transito_' . date('Ymd_His') . '.xlsx';
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header("Content-Disposition: attachment; filename=\"{$nombreArchivo}\"");
            header('Cache-Control: max-age=0');
            (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet))->save('php://output');
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
        }
    }

    public function notas_compra()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("notas_compra");
            return view('logistica/notas-compra', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }

    public function reporte_compras()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("reporte_compras");
            return view('logistica/reporte_compras', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\"); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    public function reporte_compras_pdf(Request $request)
    {
        try {
            $desde      = $request->desde ?? null;
            $hasta      = $request->hasta ?? null;
            $idProveedor = $request->proveedor ?? null;
            $agrupacion = $request->agrupacion ?? 'mensual';
            $idEmpresa  = $request->id_empresa  ? (int) $request->id_empresa  : null;
            $idSucursal = $request->id_sucursal ? (int) $request->id_sucursal : null;

            $query = DB::table('orden_compra as oc')
                ->join('proveedores as pv', 'pv.id_proveedores', '=', 'oc.id_proveedores')
                ->join('sucursals as s', 's.id_sucursal', '=', 'oc.id_sucursal')
                ->join('orden_compra_detalle as ocd', 'ocd.id_orden_compra', '=', 'oc.id_orden_compra')
                ->join('productos as p', 'p.id_pro', '=', 'ocd.id_pro')
                ->where('oc.orden_compra_estado', 'recibido');

            if ($desde && $hasta) {
                $query->whereBetween(DB::raw('DATE(oc.orden_compra_fecha)'), [$desde, $hasta]);
            }
            if ($idProveedor) {
                $query->where('oc.id_proveedores', $idProveedor);
            }
            if ($idSucursal > 0) {
                $query->where('oc.id_sucursal', $idSucursal);
            } elseif ($idEmpresa > 0) {
                $query->where('s.id_empresa', $idEmpresa);
            }

            $detalle = (clone $query)
                ->select(
                    'pv.proveedores_nombre',
                    'p.pro_nombre',
                    'p.pro_codigo',
                    DB::raw('SUM(COALESCE(ocd.detalle_compra_cantidad_recibida, ocd.detalle_compra_cantidad)) as total_cantidad'),
                    DB::raw('SUM(ocd.detalle_compra_total_pedido) as total_costo_base'),
                    DB::raw('SUM(COALESCE(ocd.flete, 0)) as total_flete'),
                    DB::raw('SUM(ocd.detalle_compra_total_pedido + COALESCE(ocd.flete, 0)) as total_costo'),
                    DB::raw('MAX(p.pro_precio_venta) as precio_venta_ref')
                )
                ->groupBy('pv.id_proveedores', 'pv.proveedores_nombre', 'p.id_pro', 'p.pro_nombre', 'p.pro_codigo')
                ->orderBy('pv.proveedores_nombre')
                ->orderByDesc('total_costo')
                ->get();

            $totales = (clone $query)
                ->selectRaw('
                    COUNT(DISTINCT oc.id_orden_compra) as num_ordenes,
                    COUNT(DISTINCT oc.id_proveedores) as num_proveedores,
                    SUM(ocd.detalle_compra_total_pedido) as total_costo_base,
                    SUM(COALESCE(ocd.flete, 0)) as total_flete,
                    SUM(ocd.detalle_compra_total_pedido + COALESCE(ocd.flete, 0)) as total_costo
                ')
                ->first();

            [$nR, $nG, $nB] = [30, 58, 95];
            [$gR, $gG, $gB] = [245, 247, 250];
            [$bR, $bG, $bB] = [210, 218, 228];

            $pdf = new PDFBufeo('L', 'mm', 'A4');
            $pdf->SetMargins(10, 10, 10);
            $pdf->SetAutoPageBreak(true, 15);
            $pdf->AddPage();
            $pdf->AliasNbPages();

            $W = 277;

            // Header
            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->Rect(10, 10, $W, 18, 'F');
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 14);
            $pdf->SetXY(10, 13);
            $pdf->Cell($W, 8, utf8_decode('REPORTE DE COMPRAS'), 0, 1, 'C');
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->SetXY(10, 22);
            $periodoTxt = ($desde && $hasta)
                ? 'Período: ' . date('d/m/Y', strtotime($desde)) . ' — ' . date('d/m/Y', strtotime($hasta))
                : 'Sin filtro de fecha';
            $pdf->Cell($W, 5, utf8_decode($periodoTxt), 0, 1, 'C');
            $pdf->SetTextColor(30, 41, 59);

            // Resumen
            $pdf->SetY(33);
            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->SetFillColor($gR, $gG, $gB);
            $summaryItems = [
                ['Órdenes recibidas', $totales->num_ordenes ?? 0],
                ['Proveedores',        $totales->num_proveedores ?? 0],
                ['Costo base total',  'S/ ' . number_format($totales->total_costo_base ?? 0, 2)],
                ['Flete total',       'S/ ' . number_format($totales->total_flete ?? 0, 2)],
                ['Costo total',       'S/ ' . number_format($totales->total_costo ?? 0, 2)],
            ];
            $bw = $W / count($summaryItems);
            foreach ($summaryItems as $s) {
                $pdf->SetFont('Helvetica', '', 6);
                $pdf->SetTextColor(100, 100, 100);
                $pdf->Cell($bw, 4, utf8_decode($s[0]), 0, 0, 'C', true);
            }
            $pdf->Ln();
            foreach ($summaryItems as $s) {
                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->Cell($bw, 6, (string) $s[1], 0, 0, 'C', true);
            }
            $pdf->Ln(10);

            // Table header
            $cols = [8, 65, 55, 22, 28, 28, 28, 30, 13];
            $heads = ['#', 'PROVEEDOR', utf8_decode('PRODUCTO'), utf8_decode('CÓDIGO'), 'CANT.', 'C. BASE', 'FLETE', 'C. TOTAL', 'P.V.R.'];
            $aligns = ['C', 'L', 'L', 'C', 'C', 'R', 'R', 'R', 'R'];

            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 6);
            foreach ($heads as $i => $h) {
                $pdf->Cell($cols[$i], 6, $h, 0, 0, $aligns[$i], true);
            }
            $pdf->Ln();

            $pdf->SetTextColor(30, 41, 59);
            $n = 1;
            $prevProv = '';
            foreach ($detalle as $idx => $row) {
                $pdf->CheckPageBreak(6);
                $fill = ($idx % 2 === 0);
                $pdf->SetFillColor($fill ? $gR : 255, $fill ? $gG : 255, $fill ? $gB : 255);
                $pdf->SetFont('Helvetica', '', 6);
                $provTxt = ($prevProv !== $row->proveedores_nombre)
                    ? utf8_decode(mb_substr($row->proveedores_nombre, 0, 35))
                    : '  ↳';
                $prevProv = $row->proveedores_nombre;
                $pdf->Cell($cols[0], 5, $n++, 'B', 0, 'C', $fill);
                $pdf->Cell($cols[1], 5, $provTxt, 'B', 0, 'L', $fill);
                $pdf->Cell($cols[2], 5, utf8_decode(mb_substr($row->pro_nombre, 0, 38)), 'B', 0, 'L', $fill);
                $pdf->Cell($cols[3], 5, $row->pro_codigo ?? '', 'B', 0, 'C', $fill);
                $pdf->Cell($cols[4], 5, number_format((float)$row->total_cantidad, 2), 'B', 0, 'C', $fill);
                $pdf->Cell($cols[5], 5, 'S/ ' . number_format((float)$row->total_costo_base, 2), 'B', 0, 'R', $fill);
                $pdf->Cell($cols[6], 5, 'S/ ' . number_format((float)$row->total_flete, 2), 'B', 0, 'R', $fill);
                $pdf->Cell($cols[7], 5, 'S/ ' . number_format((float)$row->total_costo, 2), 'B', 0, 'R', $fill);
                $pvr = (float)$row->precio_venta_ref > 0 ? 'S/ ' . number_format((float)$row->precio_venta_ref, 2) : '—';
                $pdf->Cell($cols[8], 5, $pvr, 'B', 1, 'R', $fill);
            }

            // Total row
            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 6);
            $totalCols = array_sum(array_slice($cols, 0, 5));
            $pdf->Cell($totalCols, 6, 'TOTAL GENERAL', 0, 0, 'R', true);
            $pdf->Cell($cols[5], 6, 'S/ ' . number_format((float)($totales->total_costo_base ?? 0), 2), 0, 0, 'R', true);
            $pdf->Cell($cols[6], 6, 'S/ ' . number_format((float)($totales->total_flete ?? 0), 2), 0, 0, 'R', true);
            $pdf->Cell($cols[7], 6, 'S/ ' . number_format((float)($totales->total_costo ?? 0), 2), 0, 0, 'R', true);
            $pdf->Cell($cols[8], 6, '', 0, 1, 'R', true);

            // Footer
            $pdf->SetY(-12);
            $pdf->SetDrawColor($nR, $nG, $nB);
            $pdf->Line(10, $pdf->GetY(), 10 + $W, $pdf->GetY());
            $pdf->Ln(1);
            $pdf->SetFont('Helvetica', '', 6);
            $pdf->SetTextColor(130, 130, 130);
            $pdf->SetX(10);
            $pdf->Cell($W / 2, 4, utf8_decode('Generado el ') . date('d/m/Y H:i'), 0, 0, 'L');
            $pdf->Cell($W / 2, 4, utf8_decode('Página ') . $pdf->PageNo() . ' de {nb}', 0, 0, 'R');

            $pdf->Output('I', 'Reporte-Compras-' . date('Ymd') . '.pdf');
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert('Error al generar el PDF.'); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    public function reporte_compras_excel(Request $request)
    {
        try {
            $desde      = $request->desde ?? null;
            $hasta      = $request->hasta ?? null;
            $idProveedor = $request->proveedor ?? null;
            $agrupacion = $request->agrupacion ?? 'mensual';
            $idEmpresa  = $request->id_empresa  ? (int) $request->id_empresa  : null;
            $idSucursal = $request->id_sucursal ? (int) $request->id_sucursal : null;

            $query = DB::table('orden_compra as oc')
                ->join('proveedores as pv', 'pv.id_proveedores', '=', 'oc.id_proveedores')
                ->join('sucursals as s', 's.id_sucursal', '=', 'oc.id_sucursal')
                ->join('orden_compra_detalle as ocd', 'ocd.id_orden_compra', '=', 'oc.id_orden_compra')
                ->join('productos as p', 'p.id_pro', '=', 'ocd.id_pro')
                ->where('oc.orden_compra_estado', 'recibido');

            if ($desde && $hasta) {
                $query->whereBetween(DB::raw('DATE(oc.orden_compra_fecha)'), [$desde, $hasta]);
            }
            if ($idProveedor) {
                $query->where('oc.id_proveedores', $idProveedor);
            }
            if ($idSucursal > 0) {
                $query->where('oc.id_sucursal', $idSucursal);
            } elseif ($idEmpresa > 0) {
                $query->where('s.id_empresa', $idEmpresa);
            }

            $detalle = (clone $query)
                ->select(
                    'pv.proveedores_nombre',
                    'p.pro_nombre',
                    'p.pro_codigo',
                    DB::raw('SUM(COALESCE(ocd.detalle_compra_cantidad_recibida, ocd.detalle_compra_cantidad)) as total_cantidad'),
                    DB::raw('SUM(ocd.detalle_compra_total_pedido) as total_costo_base'),
                    DB::raw('SUM(COALESCE(ocd.flete, 0)) as total_flete'),
                    DB::raw('SUM(ocd.detalle_compra_total_pedido + COALESCE(ocd.flete, 0)) as total_costo'),
                    DB::raw('MAX(p.pro_precio_venta) as precio_venta_ref'),
                    DB::raw('COUNT(DISTINCT oc.id_orden_compra) as num_ordenes')
                )
                ->groupBy('pv.id_proveedores', 'pv.proveedores_nombre', 'p.id_pro', 'p.pro_nombre', 'p.pro_codigo')
                ->orderBy('pv.proveedores_nombre')
                ->orderByDesc('total_costo')
                ->get();

            $totales = (clone $query)
                ->selectRaw('
                    COUNT(DISTINCT oc.id_orden_compra) as num_ordenes,
                    COUNT(DISTINCT oc.id_proveedores) as num_proveedores,
                    SUM(ocd.detalle_compra_total_pedido) as total_costo_base,
                    SUM(COALESCE(ocd.flete, 0)) as total_flete,
                    SUM(ocd.detalle_compra_total_pedido + COALESCE(ocd.flete, 0)) as total_costo
                ')
                ->first();

            $groupFormat = $agrupacion === 'diario'
                ? "DATE_FORMAT(oc.orden_compra_fecha, '%Y-%m-%d')"
                : "DATE_FORMAT(oc.orden_compra_fecha, '%Y-%m')";
            $labelFormat = $agrupacion === 'diario'
                ? "DATE_FORMAT(oc.orden_compra_fecha, '%d/%m/%Y')"
                : "DATE_FORMAT(oc.orden_compra_fecha, '%m/%Y')";

            $porPeriodo = (clone $query)
                ->select(
                    DB::raw("{$labelFormat} as periodo_label"),
                    DB::raw('COUNT(DISTINCT oc.id_orden_compra) as num_ordenes'),
                    DB::raw('COUNT(DISTINCT oc.id_proveedores) as num_proveedores'),
                    DB::raw('SUM(ocd.detalle_compra_total_pedido) as total_costo_base'),
                    DB::raw('SUM(COALESCE(ocd.flete, 0)) as total_flete'),
                    DB::raw('SUM(ocd.detalle_compra_total_pedido + COALESCE(ocd.flete, 0)) as total_costo')
                )
                ->groupByRaw("{$groupFormat}, {$labelFormat}")
                ->orderByRaw($groupFormat)
                ->get();

            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $navy = 'FF1E3A5F';
            $white = 'FFFFFFFF';
            $gray = 'FFF5F7FA';

            $estiloTitulo = [
                'font'      => ['bold' => true, 'size' => 13, 'color' => ['argb' => $navy], 'name' => 'Arial'],
                'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
            ];
            $estiloEnc = [
                'font'      => ['bold' => true, 'color' => ['argb' => $white], 'size' => 8, 'name' => 'Arial'],
                'fill'      => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['argb' => $navy]],
                'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER, 'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER, 'wrapText' => true],
                'borders'   => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN, 'color' => ['argb' => $white]]],
            ];
            $estiloBorde = [
                'borders'   => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN, 'color' => ['argb' => 'FFD0D0D0']]],
                'font'      => ['size' => 8, 'name' => 'Arial'],
                'alignment' => ['vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER],
            ];

            // ── HOJA 1: Por Proveedor ──────────────────────────────
            $sheet1 = $spreadsheet->getActiveSheet();
            $sheet1->setTitle('Por Proveedor');

            $sheet1->mergeCells('A1:I1');
            $sheet1->setCellValue('A1', 'Reporte de Compras — Por Proveedor');
            $sheet1->getStyle('A1')->applyFromArray($estiloTitulo);
            $sheet1->getRowDimension(1)->setRowHeight(20);

            $periodo = ($desde && $hasta)
                ? date('d/m/Y', strtotime($desde)) . ' al ' . date('d/m/Y', strtotime($hasta))
                : 'Sin filtro';
            $sheet1->setCellValue('A2', 'Período:');
            $sheet1->getStyle('A2')->applyFromArray(['font' => ['bold' => true, 'size' => 8]]);
            $sheet1->setCellValue('B2', $periodo);
            $sheet1->getStyle('B2')->applyFromArray(['font' => ['size' => 8]]);

            $encH1 = ['A' => '#', 'B' => 'Proveedor', 'C' => 'Producto', 'D' => 'Código', 'E' => 'Cant.', 'F' => 'Costo base', 'G' => 'Flete', 'H' => 'Costo total', 'I' => 'P.V. Referencial'];
            $fila = 4;
            foreach ($encH1 as $col => $txt) {
                $sheet1->setCellValue("{$col}{$fila}", $txt);
            }
            $sheet1->getStyle("A{$fila}:I{$fila}")->applyFromArray($estiloEnc);
            $sheet1->getRowDimension($fila)->setRowHeight(18);

            $fila = 5;
            foreach ($detalle as $i => $row) {
                $sheet1->setCellValue("A{$fila}", $i + 1);
                $sheet1->setCellValue("B{$fila}", $row->proveedores_nombre);
                $sheet1->setCellValue("C{$fila}", $row->pro_nombre);
                $sheet1->setCellValue("D{$fila}", $row->pro_codigo);
                $sheet1->setCellValue("E{$fila}", (float)$row->total_cantidad);
                $sheet1->setCellValue("F{$fila}", (float)$row->total_costo_base);
                $sheet1->setCellValue("G{$fila}", (float)$row->total_flete);
                $sheet1->setCellValue("H{$fila}", (float)$row->total_costo);
                $sheet1->setCellValue("I{$fila}", (float)$row->precio_venta_ref);
                $sheet1->getStyle("A{$fila}:I{$fila}")->applyFromArray($estiloBorde);
                if ($i % 2 === 0) {
                    $sheet1->getStyle("A{$fila}:I{$fila}")->applyFromArray(['fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['argb' => 'FFF5F7FA']]]);
                }
                $fila++;
            }

            // Total row
            $sheet1->setCellValue("E{$fila}", 'TOTAL');
            $sheet1->setCellValue("F{$fila}", (float)($totales->total_costo_base ?? 0));
            $sheet1->setCellValue("G{$fila}", (float)($totales->total_flete ?? 0));
            $sheet1->setCellValue("H{$fila}", (float)($totales->total_costo ?? 0));
            $sheet1->getStyle("A{$fila}:I{$fila}")->applyFromArray([
                'font' => ['bold' => true, 'color' => ['argb' => $white]],
                'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['argb' => $navy]],
            ]);

            foreach (['A' => 5, 'B' => 30, 'C' => 35, 'D' => 14, 'E' => 12, 'F' => 14, 'G' => 12, 'H' => 14, 'I' => 14] as $col => $w) {
                $sheet1->getColumnDimension($col)->setWidth($w);
            }
            $sheet1->getStyle("F5:I{$fila}")->getNumberFormat()->setFormatCode('#,##0.00');

            // ── HOJA 2: Por Período ────────────────────────────────
            $sheet2 = $spreadsheet->createSheet();
            $sheet2->setTitle('Por Período');

            $sheet2->mergeCells('A1:H1');
            $sheet2->setCellValue('A1', 'Reporte de Compras — Por ' . ($agrupacion === 'diario' ? 'Día' : 'Mes'));
            $sheet2->getStyle('A1')->applyFromArray($estiloTitulo);
            $sheet2->getRowDimension(1)->setRowHeight(20);

            $encH2 = ['A' => '#', 'B' => ($agrupacion === 'diario' ? 'Fecha' : 'Mes'), 'C' => 'Órdenes', 'D' => 'Proveedores', 'E' => 'Cant. ítems', 'F' => 'Costo base', 'G' => 'Flete', 'H' => 'Costo total'];
            $fila2 = 3;
            foreach ($encH2 as $col => $txt) {
                $sheet2->setCellValue("{$col}{$fila2}", $txt);
            }
            $sheet2->getStyle("A{$fila2}:H{$fila2}")->applyFromArray($estiloEnc);
            $sheet2->getRowDimension($fila2)->setRowHeight(18);

            $fila2 = 4;
            foreach ($porPeriodo as $i => $p) {
                $sheet2->setCellValue("A{$fila2}", $i + 1);
                $sheet2->setCellValue("B{$fila2}", $p->periodo_label);
                $sheet2->setCellValue("C{$fila2}", (int)$p->num_ordenes);
                $sheet2->setCellValue("D{$fila2}", (int)$p->num_proveedores);
                $sheet2->setCellValue("E{$fila2}", (float)$p->total_cantidad);
                $sheet2->setCellValue("F{$fila2}", (float)$p->total_costo_base);
                $sheet2->setCellValue("G{$fila2}", (float)$p->total_flete);
                $sheet2->setCellValue("H{$fila2}", (float)$p->total_costo);
                $sheet2->getStyle("A{$fila2}:H{$fila2}")->applyFromArray($estiloBorde);
                if ($i % 2 === 0) {
                    $sheet2->getStyle("A{$fila2}:H{$fila2}")->applyFromArray(['fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['argb' => 'FFF5F7FA']]]);
                }
                $fila2++;
            }

            $sheet2->setCellValue("E{$fila2}", 'TOTAL');
            $sheet2->setCellValue("F{$fila2}", (float)($totales->total_costo_base ?? 0));
            $sheet2->setCellValue("G{$fila2}", (float)($totales->total_flete ?? 0));
            $sheet2->setCellValue("H{$fila2}", (float)($totales->total_costo ?? 0));
            $sheet2->getStyle("A{$fila2}:H{$fila2}")->applyFromArray([
                'font' => ['bold' => true, 'color' => ['argb' => $white]],
                'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['argb' => $navy]],
            ]);

            foreach (['A' => 5, 'B' => 15, 'C' => 10, 'D' => 12, 'E' => 12, 'F' => 14, 'G' => 12, 'H' => 14] as $col => $w) {
                $sheet2->getColumnDimension($col)->setWidth($w);
            }
            $sheet2->getStyle("F4:H{$fila2}")->getNumberFormat()->setFormatCode('#,##0.00');

            $spreadsheet->setActiveSheetIndex(0);

            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $filename = 'Reporte-Compras-' . date('Ymd-His') . '.xlsx';

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header("Content-Disposition: attachment; filename=\"{$filename}\"");
            header('Cache-Control: max-age=0');
            $writer->save('php://output');
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert('Error al generar el Excel.'); window.location.href = '" . route('admin') . "';</script>";
        }
    }

    public function compras_pdf()
    {
        try {
            $id = $_GET['ordenCompra'] ?? null;
            if (!$id) {
                echo "<script>alert('Error'); window.location.href = '" . route('admin') . "';</script>";
                return;
            }

            $oc = DB::table('orden_compra as oc')
                ->join('proveedores as pv', 'pv.id_proveedores', '=', 'oc.id_proveedores')
                ->join('users as u', 'u.id_users', '=', 'oc.id_solicitante')
                ->leftJoin('persona as pe', 'pe.id_persona', '=', 'u.id_persona')
                ->leftJoin('tiendas as t', 't.id_tienda', '=', 'oc.id_sucursal')
                ->leftJoin('tipo_pago as tp', 'tp.id_tipo_pago', '=', 'oc.id_tipo_pago')
                ->select(
                    'oc.*',
                    'pv.proveedores_nombre', 'pv.proveedores_numero_documento',
                    'u.nombre_users', 'u.email as user_email',
                    'pe.persona_dni', 'pe.persona_telefono',
                    'pe.persona_nombre', 'pe.persona_apellido_paterno', 'pe.persona_apellido_materno',
                    'tp.tipo_pago_nombre',
                    't.tienda_nombre as sucursal_nombre',
                    't.id_empresa',
                )
                ->where('oc.id_orden_compra', $id)
                ->first();

            if (!$oc) {
                return redirect()->route('logistica.compras');
            }

            $detalle = DB::table('orden_compra_detalle as ocd')
                ->join('productos as p', 'p.id_pro', '=', 'ocd.id_pro')
                ->select('ocd.*', 'p.pro_codigo')
                ->where('ocd.id_orden_compra', $id)
                ->get();

            $emp = $oc->id_empresa
                ? DB::table('empresa')->where('id_empresa', $oc->id_empresa)->first()
                : null;

            $subtotal = (float) $detalle->sum('detalle_compra_total_pedido');
            $flete    = (float) ($oc->orden_compra_flete ?? 0);
            $gastos   = (float) ($oc->orden_compra_gastos_operativos ?? 0);
            $total    = $subtotal + $flete + $gastos;

            // ── Paleta de colores ────────────────────────────────
            [$nR, $nG, $nB] = [30,  58,  95];   // navy  #1E3A5F
            [$gR, $gG, $gB] = [245, 247, 250];  // gray bg
            [$bR, $bG, $bB] = [210, 218, 228];  // border

            $pdf = new PDFBufeo('P', 'mm', 'A4');
            $pdf->SetMargins(12, 12, 12);
            $pdf->SetAutoPageBreak(true, 18);
            $pdf->AddPage();
            $pdf->AliasNbPages();

            $W = 186; // ancho útil (210 - 24)

            // ════════════════════════════════════════════════════
            // BANDA HEADER
            // ════════════════════════════════════════════════════
            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->Rect(12, 12, $W, 30, 'F');

            // Logo (izquierda)
            if ($emp && !empty($emp->empresa_foto) && file_exists($emp->empresa_foto)) {
                $pdf->Image($emp->empresa_foto, 15, 15, 0, 24);
            }

            // Título OC (derecha)
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 20);
            $pdf->SetXY(12, 15);
            $pdf->Cell($W - 4, 10, 'COMPRA', 0, 1, 'R');

            // Número OC
            $pdf->SetFont('Helvetica', 'B', 10);
            $pdf->SetXY(12, 26);
            $pdf->Cell($W - 4, 6, utf8_decode($oc->orden_compra_numero), 0, 1, 'R');

            // Fecha
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->SetXY(12, 33);
            $pdf->Cell($W - 4, 5, 'Fecha: ' . date('d/m/Y', strtotime($oc->orden_compra_fecha)), 0, 1, 'R');

            $pdf->SetTextColor(30, 41, 59);

            // ════════════════════════════════════════════════════
            // BLOQUE: EMPRESA (izq) | INFO OC (der)
            // ════════════════════════════════════════════════════
            $y0   = 47;
            $cL   = 108; // ancho col izquierda
            $cR   = 78;  // ancho col derecha
            $xR   = 12 + $cL;
            $rowH = 5;

            // ── Empresa ──────────────────────────────────────────
            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->SetTextColor($nR, $nG, $nB);
            $pdf->SetXY(12, $y0);
            $pdf->Cell($cL, 5, 'EMPRESA EMISORA', 0, 1, 'L');
            $pdf->SetDrawColor($nR, $nG, $nB);
            $pdf->Line(12, $pdf->GetY(), 12 + $cL, $pdf->GetY());

            $yEmp = $pdf->GetY() + 1;
            $datosEmp = [
                ['RUC',        $emp->empresa_ruc ?? '-'],
                ['Razón Social', utf8_decode($emp->empresa_razon_social ?? '-')],
                ['Dirección',  utf8_decode($emp->empresa_domiciliofiscal ?? '-')],
                ['Tel.',       trim(($emp->empresa_telefono1 ?? '') . ' ' . ($emp->empresa_telefono2 ?? '')) ?: '-'],
                ['Correo',     $emp->empresa_correo ?? '-'],
            ];
            foreach ($datosEmp as [$lbl, $val]) {
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor(100, 100, 100);
                $pdf->SetXY(12, $yEmp);
                $pdf->Cell(22, $rowH, utf8_decode($lbl) . ':', 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->MultiAlignCell($cL - 22, $rowH, $val, 0, 1, 'L');
                $yEmp += $rowH;
            }

            // ── Info OC (caja sombreada derecha) ─────────────────
            $pdf->SetFillColor($gR, $gG, $gB);
            $pdf->SetDrawColor($bR, $bG, $bB);
            $pdf->Rect($xR, $y0, $cR, 50, 'DF');

            $nombreCompleto = trim(implode(' ', array_filter([
                $oc->persona_nombre,
                $oc->persona_apellido_paterno,
                $oc->persona_apellido_materno,
            ]))) ?: ($oc->nombre_users ?? '-');

            $yOC = $y0 + 2;
            $datosOC = [
                ['N° Compra',  utf8_decode($oc->orden_compra_numero)],
                ['Estado',     strtoupper($oc->orden_compra_estado ?? '-')],
                ['Fecha OC',   date('d/m/Y', strtotime($oc->orden_compra_fecha))],
                ['F. Emision', $oc->orden_compra_fecha_emision_doc
                    ? date('d/m/Y', strtotime($oc->orden_compra_fecha_emision_doc)) : '-'],
                ['Sucursal',   utf8_decode($oc->sucursal_nombre ?? '-')],
                ['Solicitante', utf8_decode($nombreCompleto)],
                ['DNI',        $oc->persona_dni ?? '-'],
                ['Telefono',   $oc->persona_telefono ?? '-'],
                ['Correo',     $oc->user_email ?? '-'],
            ];
            foreach ($datosOC as [$lbl, $val]) {
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor(100, 100, 100);
                $pdf->SetXY($xR + 2, $yOC);
                $pdf->Cell(22, $rowH, utf8_decode($lbl) . ':', 0, 0, 'L');
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->Cell($cR - 26, $rowH, $val, 0, 1, 'L');
                $yOC += $rowH;
            }

            // ════════════════════════════════════════════════════
            // BLOQUE: PROVEEDOR (izq) | COMPRA INFO (der)
            // ════════════════════════════════════════════════════
            $y1 = max($yEmp, $y0 + 54) + 4;

            // ── Proveedor ─────────────────────────────────────────
            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->SetTextColor($nR, $nG, $nB);
            $pdf->SetXY(12, $y1);
            $pdf->Cell($cL, 5, 'PROVEEDOR', 0, 1, 'L');
            $pdf->SetDrawColor($nR, $nG, $nB);
            $pdf->Line(12, $pdf->GetY(), 12 + $cL, $pdf->GetY());

            $yProv = $pdf->GetY() + 1;
            $datosProv = [
                ['Nombre',    utf8_decode($oc->proveedores_nombre ?? '-')],
                ['RUC / Doc', $oc->proveedores_numero_documento ?? '-'],
                ['Tipo comp.', utf8_decode($oc->orden_compra_tipo_doc ?? '-')],
                ['N Comp.',  $oc->orden_compra_numero_doc ?? '-'],
            ];
            foreach ($datosProv as [$lbl, $val]) {
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor(100, 100, 100);
                $pdf->SetXY(12, $yProv);
                $pdf->Cell(22, $rowH, utf8_decode($lbl) . ':', 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->MultiAlignCell($cL - 22, $rowH, $val, 0, 1, 'L');
                $yProv += $rowH;
            }

            // ── Info compra (derecha) ─────────────────────────────
            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->SetTextColor($nR, $nG, $nB);
            $pdf->SetXY($xR, $y1);
            $pdf->Cell($cR, 5, 'DATOS DE COMPRA', 0, 1, 'L');
            $pdf->SetDrawColor($nR, $nG, $nB);
            $pdf->Line($xR, $y1 + 5, $xR + $cR, $y1 + 5);

            $yComp = $y1 + 6;
            $datosComp = [
                ['Forma de pago',  utf8_decode($oc->tipo_pago_nombre ?? '-')],
                ['Flete',          'S/ ' . number_format($flete, 2)],
                ['Gastos Op.',     'S/ ' . number_format($gastos, 2)],
                ['Total compra',   'S/ ' . number_format($total, 2)],
            ];
            foreach ($datosComp as [$lbl, $val]) {
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor(100, 100, 100);
                $pdf->SetXY($xR, $yComp);
                $pdf->Cell(24, $rowH, utf8_decode($lbl) . ':', 0, 0, 'L');
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->Cell($cR - 24, $rowH, $val, 0, 1, 'L');
                $yComp += $rowH;
            }

            // ════════════════════════════════════════════════════
            // TABLA DE ITEMS
            // ════════════════════════════════════════════════════
            $yTable = max($yProv, $yComp) + 6;
            $pdf->SetY($yTable);

            // Anchos: # | Producto | Código | Cant | P.Compra | Total = 186
            $cW = [8, 83, 28, 18, 26, 23];
            $cH = ['#', utf8_decode('PRODUCTO / DESCRIPCIÓN'), utf8_decode('CÓDIGO'), 'CANT.', 'P. COMPRA', 'TOTAL'];
            $cA = ['C', 'L', 'C', 'C', 'R', 'R'];

            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetDrawColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 7);
            foreach ($cH as $i => $h) {
                $pdf->Cell($cW[$i], 7, $h, 0, 0, $cA[$i], true);
            }
            $pdf->Ln();

            $pdf->SetDrawColor($bR, $bG, $bB);
            $pdf->SetTextColor(30, 41, 59);
            foreach ($detalle as $idx => $item) {
                $pdf->CheckPageBreak(7);
                $fill = ($idx % 2 === 0);
                $pdf->SetFillColor($fill ? $gR : 255, $fill ? $gG : 255, $fill ? $gB : 255);
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell($cW[0], 6, $idx + 1, 'B', 0, 'C', $fill);
                $pdf->Cell($cW[1], 6, utf8_decode(mb_substr($item->detalle_orden_nombre_producto ?? '', 0, 52)), 'B', 0, 'L', $fill);
                $pdf->Cell($cW[2], 6, $item->pro_codigo ?? '', 'B', 0, 'C', $fill);
                $pdf->Cell($cW[3], 6, number_format((float)$item->detalle_compra_cantidad, 2), 'B', 0, 'C', $fill);
                $pdf->Cell($cW[4], 6, 'S/ ' . number_format((float)$item->detalle_compra_precio_compra, 2), 'B', 0, 'R', $fill);
                $pdf->Cell($cW[5], 6, 'S/ ' . number_format((float)$item->detalle_compra_total_pedido, 2), 'B', 0, 'R', $fill);
                $pdf->Ln();
            }

            // ════════════════════════════════════════════════════
            // TOTALES
            // ════════════════════════════════════════════════════
            $pdf->Ln(4);
            $xTot = 12 + $W - 88;
            $wLbl = 58;
            $wVal = 30;

            $lineas = [
                ['Subtotal de productos', 'S/ ' . number_format($subtotal, 2)],
                ['Flete',                 'S/ ' . number_format($flete, 2)],
                ['Gastos operativos',     'S/ ' . number_format($gastos, 2)],
            ];
            $pdf->SetDrawColor($bR, $bG, $bB);
            foreach ($lineas as [$lbl, $val]) {
                $pdf->SetXY($xTot, $pdf->GetY());
                $pdf->SetFillColor($gR, $gG, $gB);
                $pdf->SetFont('Helvetica', '', 8);
                $pdf->SetTextColor(80, 80, 80);
                $pdf->Cell($wLbl, 6, utf8_decode($lbl), 'B', 0, 'R', true);
                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->Cell($wVal, 6, $val, 'B', 1, 'R', true);
            }

            // Línea total (navy)
            $pdf->SetXY($xTot, $pdf->GetY());
            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 9);
            $pdf->Cell($wLbl, 8, 'TOTAL', 0, 0, 'R', true);
            $pdf->Cell($wVal, 8, 'S/ ' . number_format($total, 2), 0, 1, 'R', true);

            // ════════════════════════════════════════════════════
            // OBSERVACIÓN
            // ════════════════════════════════════════════════════
            if (!empty($oc->orden_compra_observacion)) {
                $pdf->Ln(5);
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->SetTextColor($nR, $nG, $nB);
                $pdf->SetXY(12, $pdf->GetY());
                $pdf->Cell($W, 5, utf8_decode('OBSERVACIÓN'), 0, 1, 'L');
                $pdf->SetDrawColor($nR, $nG, $nB);
                $pdf->Line(12, $pdf->GetY(), 12 + $W, $pdf->GetY());
                $pdf->Ln(1);
                $pdf->SetFillColor($gR, $gG, $gB);
                $pdf->SetFont('Helvetica', '', 8);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->SetX(12);
                $pdf->MultiCell($W, 5, utf8_decode($oc->orden_compra_observacion), 0, 'L', true);
            }

            // ════════════════════════════════════════════════════
            // FOOTER
            // ════════════════════════════════════════════════════
            $pdf->SetAutoPageBreak(false);
            $pdf->SetY(-16);
            $pdf->SetDrawColor($nR, $nG, $nB);
            $pdf->Line(12, $pdf->GetY(), 12 + $W, $pdf->GetY());
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->SetTextColor(130, 130, 130);
            $pdf->SetXY(12, $pdf->GetY() + 2);
            $pdf->Cell($W / 2, 5, utf8_decode('Generado el ') . date('d/m/Y H:i'), 0, 0, 'L');
            $pdf->Cell($W / 2, 5, utf8_decode('Página ') . $pdf->PageNo() . ' de {nb}', 0, 0, 'R');

            $pdf->Output('I', 'Compra-' . $oc->orden_compra_numero . '.pdf');
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert('Error al generar el PDF.');
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }








    // =====================================================================
    //  KARDEX VALORIZADO
    // =====================================================================

    public function kardex_valorizado()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("kardex_valorizado");
            return view("logistica/kardex_valorizado", compact("opciones"));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert(\"Error Al Mostrar Contenido.\"); window.location.href = '" . route("admin") . "';</script>";
        }
    }

    public function gastos()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("gastos");
            return view('logistica/gastos', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }

    public function autoconsumo()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("autoconsumo");
            return view('logistica/autoconsumo', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }

    public function kardex_valorizado_pdf(\Illuminate\Http\Request $request)
    {
        try {
            $idPro      = (int) $request->id_pro;
            $desde      = $request->desde ?? null;
            $hasta      = $request->hasta ?? null;
            $idEmpresa  = $request->id_empresa  ? (int) $request->id_empresa  : null;
            $idSucursal = $request->id_sucursal ? (int) $request->id_sucursal : null;

            $producto = \Illuminate\Support\Facades\DB::table("productos")->where("id_pro", $idPro)->first(["pro_nombre", "pro_codigo"]);
            [$lineas, $saldoInicial, $totales] = $this->calcularKardex($idPro, $desde, $hasta, $idEmpresa, $idSucursal);

            $sucursalNombre = $idSucursal > 0
                ? (\Illuminate\Support\Facades\DB::table("sucursals")->where("id_sucursal", $idSucursal)->value("sucursal_nombre") ?? "")
                : "";

            [$nR, $nG, $nB] = [30, 58, 95];
            [$gR, $gG, $gB] = [245, 247, 250];

            $pdf = new \App\Models\PDFBufeo("L", "mm", "A4");
            $pdf->SetMargins(8, 8, 8);
            $pdf->SetAutoPageBreak(true, 12);
            $pdf->AddPage();
            $pdf->AliasNbPages();
            $W = 281;

            $pdf->SetFillColor($nR, $nG, $nB);
            $pdf->Rect(8, 8, $W, 16, "F");
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont("Helvetica", "B", 13);
            $pdf->SetXY(8, 10);
            $pdf->Cell($W, 7, utf8_decode("KARDEX VALORIZADO"), 0, 1, "C");
            $pdf->SetFont("Helvetica", "", 7);
            $pdf->SetXY(8, 18);
            $productoTxt = $producto ? utf8_decode($producto->pro_nombre . " [" . $producto->pro_codigo . "]") : "";
            $periodoTxt  = ($desde && $hasta)
                ? "Periodo: " . date("d/m/Y", strtotime($desde)) . " - " . date("d/m/Y", strtotime($hasta))
                : "Sin filtro de fecha";
            $pdf->Cell($W / 2, 4, $productoTxt, 0, 0, "L");
            $pdf->Cell($W / 2, 4, utf8_decode($periodoTxt . ($sucursalNombre ? " | " . $sucursalNombre : "")), 0, 1, "R");
            $pdf->SetTextColor(30, 41, 59);
            $pdf->SetY(28);

            $colFecha = 20; $colTipo = 22; $colMotivo = 62;
            $colCant  = 16; $colCU   = 20; $colTotal  = 22;
            $colSCant = 16; $colSValor = 22;

            $pdf->SetFont("Helvetica", "B", 6);
            $pdf->SetFillColor(30, 58, 95); $pdf->SetTextColor(255,255,255);
            $pdf->Cell($colFecha + $colTipo + $colMotivo, 5, "", 0, 0, "C", true);
            $pdf->SetFillColor(26, 107, 53);
            $pdf->Cell($colCant + $colCU + $colTotal, 5, "ENTRADAS", 1, 0, "C", true);
            $pdf->SetFillColor(123, 30, 30);
            $pdf->Cell($colCant + $colCU + $colTotal, 5, "SALIDAS", 1, 0, "C", true);
            $pdf->SetFillColor(26, 58, 107);
            $pdf->Cell($colSCant + $colSValor, 5, "SALDO", 1, 1, "C", true);

            $pdf->SetFillColor($nR, $nG, $nB); $pdf->SetTextColor(255,255,255);
            $heads  = ["Fecha","Tipo",utf8_decode("Motivo"),"Cant.","C.Unit.","Total","Cant.","C.Unit.","Total","Cant.","Valorizado"];
            $widths = [$colFecha,$colTipo,$colMotivo,$colCant,$colCU,$colTotal,$colCant,$colCU,$colTotal,$colSCant,$colSValor];
            foreach ($heads as $hi => $h) { $pdf->Cell($widths[$hi], 5, $h, 0, 0, "C", true); }
            $pdf->Ln();

            $pdf->SetFillColor(220, 228, 245); $pdf->SetTextColor(30,41,59);
            $pdf->SetFont("Helvetica", "B", 6);
            $pdf->Cell($colFecha, 5, "-", "B", 0, "C", true);
            $pdf->Cell($colTipo, 5, "SALDO INIC.", "B", 0, "C", true);
            $pdf->Cell($colMotivo, 5, utf8_decode("Saldo acumulado antes del periodo"), "B", 0, "L", true);
            $pdf->Cell($colCant+$colCU+$colTotal, 5, "-", "B", 0, "C", true);
            $pdf->Cell($colCant+$colCU+$colTotal, 5, "-", "B", 0, "C", true);
            $pdf->Cell($colSCant, 5, number_format($saldoInicial["cantidad"], 2), "B", 0, "R", true);
            $pdf->Cell($colSValor, 5, "S/ ".number_format($saldoInicial["valor"], 2), "B", 1, "R", true);

            $pdf->SetFont("Helvetica", "", 6);
            foreach ($lineas as $idx => $ln) {
                $pdf->CheckPageBreak(5);
                $fill = ($idx % 2 === 0);
                $pdf->SetFillColor($fill ? $gR : 255, $fill ? $gG : 255, $fill ? $gB : 255);
                $pdf->SetTextColor(30, 41, 59);
                $pdf->Cell($colFecha,  5, date("d/m/Y", strtotime($ln["fecha"])), "B", 0, "C", $fill);
                $pdf->Cell($colTipo,   5, $ln["tipo"] === 1 ? "INGRESO" : "SALIDA", "B", 0, "C", $fill);
                $pdf->Cell($colMotivo, 5, utf8_decode(mb_substr($ln["motivo"] ?? "", 0, 38)), "B", 0, "L", $fill);
                $pdf->Cell($colCant,  5, $ln["entrada_cant"]  !== null ? number_format($ln["entrada_cant"], 2)        : "-", "B", 0, "R", $fill);
                $pdf->Cell($colCU,    5, $ln["entrada_cu"]    !== null ? number_format($ln["entrada_cu"], 4)          : "-", "B", 0, "R", $fill);
                $pdf->Cell($colTotal, 5, $ln["entrada_total"] !== null ? "S/ ".number_format($ln["entrada_total"], 2) : "-", "B", 0, "R", $fill);
                $pdf->Cell($colCant,  5, $ln["salida_cant"]   !== null ? number_format($ln["salida_cant"], 2)         : "-", "B", 0, "R", $fill);
                $pdf->Cell($colCU,    5, $ln["salida_cu"]     !== null ? number_format($ln["salida_cu"], 4)           : "-", "B", 0, "R", $fill);
                $pdf->Cell($colTotal, 5, $ln["salida_total"]  !== null ? "S/ ".number_format($ln["salida_total"], 2)  : "-", "B", 0, "R", $fill);
                $pdf->Cell($colSCant,  5, number_format($ln["saldo_cant"], 2),        "B", 0, "R", $fill);
                $pdf->Cell($colSValor, 5, "S/ ".number_format($ln["saldo_valor"], 2), "B", 1, "R", $fill);
            }

            if ($totales) {
                $pdf->SetFillColor($nR, $nG, $nB); $pdf->SetTextColor(255,255,255);
                $pdf->SetFont("Helvetica", "B", 6);
                $pdf->Cell($colFecha+$colTipo+$colMotivo, 5, "TOTALES DEL PERIODO", 0, 0, "R", true);
                $pdf->Cell($colCant,   5, number_format($totales["entrada_cant"], 2),        0, 0, "R", true);
                $pdf->Cell($colCU,     5, "",                                                 0, 0, "R", true);
                $pdf->Cell($colTotal,  5, "S/ ".number_format($totales["entrada_valor"], 2), 0, 0, "R", true);
                $pdf->Cell($colCant,   5, number_format($totales["salida_cant"], 2),         0, 0, "R", true);
                $pdf->Cell($colCU,     5, "",                                                 0, 0, "R", true);
                $pdf->Cell($colTotal,  5, "S/ ".number_format($totales["salida_valor"], 2),  0, 0, "R", true);
                $pdf->Cell($colSCant,  5, number_format($totales["saldo_cant"], 2),          0, 0, "R", true);
                $pdf->Cell($colSValor, 5, "S/ ".number_format($totales["saldo_valor"], 2),   0, 1, "R", true);
            }

            $pdf->SetY(-10); $pdf->SetFont("Helvetica", "", 6); $pdf->SetTextColor(130,130,130);
            $pdf->SetX(8);
            $pdf->Cell($W/2, 4, utf8_decode("Generado el ") . date("d/m/Y H:i"), 0, 0, "L");
            $pdf->Cell($W/2, 4, utf8_decode("Pagina ") . $pdf->PageNo() . " de {nb}", 0, 0, "R");

            $pdf->Output("I", "Kardex-" . date("Ymd") . ".pdf");
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert('Error al generar el PDF.'); window.history.back();</script>";
        }
    }

    public function kardex_valorizado_excel(\Illuminate\Http\Request $request)
    {
        try {
            $idPro      = (int) $request->id_pro;
            $desde      = $request->desde ?? null;
            $hasta      = $request->hasta ?? null;
            $idEmpresa  = $request->id_empresa  ? (int) $request->id_empresa  : null;
            $idSucursal = $request->id_sucursal ? (int) $request->id_sucursal : null;

            $producto = \Illuminate\Support\Facades\DB::table("productos")->where("id_pro", $idPro)->first(["pro_nombre", "pro_codigo"]);
            [$lineas, $saldoInicial, $totales] = $this->calcularKardex($idPro, $desde, $hasta, $idEmpresa, $idSucursal);

            $sucursalNombre = $idSucursal > 0
                ? (\Illuminate\Support\Facades\DB::table("sucursals")->where("id_sucursal", $idSucursal)->value("sucursal_nombre") ?? "")
                : "";

            $navy  = "FF1E3A5F"; $white = "FFFFFFFF";
            $green = "FF1A6B35"; $red   = "FF7B1E1E"; $blue  = "FF1A3A6B";

            $estiloEnc = [
                "font"      => ["bold" => true, "color" => ["argb" => $white], "size" => 8, "name" => "Arial"],
                "fill"      => ["fillType" => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, "startColor" => ["argb" => $navy]],
                "alignment" => ["horizontal" => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER, "vertical" => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER],
                "borders"   => ["allBorders" => ["borderStyle" => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN, "color" => ["argb" => $white]]],
            ];
            $estiloBorde = [
                "borders" => ["allBorders" => ["borderStyle" => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN, "color" => ["argb" => "FFD0D0D0"]]],
                "font"    => ["size" => 8, "name" => "Arial"],
            ];

            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle("Kardex");

            $sheet->mergeCells("A1:K1");
            $sheet->setCellValue("A1", "KARDEX VALORIZADO");
            $sheet->getStyle("A1")->applyFromArray([
                "font"      => ["bold" => true, "size" => 14, "color" => ["argb" => $navy], "name" => "Arial"],
                "alignment" => ["horizontal" => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
            ]);
            $sheet->getRowDimension(1)->setRowHeight(22);

            $productoTxt = $producto ? $producto->pro_nombre . " [" . $producto->pro_codigo . "]" : "";
            $periodoTxt  = ($desde && $hasta)
                ? date("d/m/Y", strtotime($desde)) . " al " . date("d/m/Y", strtotime($hasta))
                : "Sin filtro";
            $sheet->mergeCells("A2:K2");
            $sheet->setCellValue("A2", $productoTxt . " | Periodo: " . $periodoTxt . ($sucursalNombre ? " | " . $sucursalNombre : ""));
            $sheet->getStyle("A2")->applyFromArray(["font" => ["size" => 8, "italic" => true]]);

            $sheet->mergeCells("D4:F4"); $sheet->setCellValue("D4", "ENTRADAS");
            $sheet->mergeCells("G4:I4"); $sheet->setCellValue("G4", "SALIDAS");
            $sheet->mergeCells("J4:K4"); $sheet->setCellValue("J4", "SALDO");
            $sheet->getStyle("D4:F4")->applyFromArray(["fill" => ["fillType" => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, "startColor" => ["argb" => $green]], "font" => ["bold" => true, "color" => ["argb" => $white], "size" => 8], "alignment" => ["horizontal" => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]]);
            $sheet->getStyle("G4:I4")->applyFromArray(["fill" => ["fillType" => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, "startColor" => ["argb" => $red]],   "font" => ["bold" => true, "color" => ["argb" => $white], "size" => 8], "alignment" => ["horizontal" => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]]);
            $sheet->getStyle("J4:K4")->applyFromArray(["fill" => ["fillType" => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, "startColor" => ["argb" => $blue]],  "font" => ["bold" => true, "color" => ["argb" => $white], "size" => 8], "alignment" => ["horizontal" => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]]);

            foreach (["A" => "Fecha", "B" => "Tipo", "C" => "Motivo / Referencia",
                      "D" => "E.Cant.", "E" => "E.C.Unit.", "F" => "E.Total",
                      "G" => "S.Cant.", "H" => "S.C.Unit.", "I" => "S.Total",
                      "J" => "Saldo Cant.", "K" => "Saldo Valor"] as $col => $txt) {
                $sheet->setCellValue("{$col}5", $txt);
            }
            $sheet->getStyle("A5:K5")->applyFromArray($estiloEnc);
            $sheet->getRowDimension(5)->setRowHeight(16);

            $fila = 6;
            $sheet->setCellValue("A{$fila}", "-");
            $sheet->setCellValue("B{$fila}", "SALDO INICIAL");
            $sheet->setCellValue("C{$fila}", "Saldo acumulado antes del periodo");
            $sheet->setCellValue("J{$fila}", (float) $saldoInicial["cantidad"]);
            $sheet->setCellValue("K{$fila}", (float) $saldoInicial["valor"]);
            $sheet->getStyle("A{$fila}:K{$fila}")->applyFromArray(["fill" => ["fillType" => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, "startColor" => ["argb" => "FFE8EDF8"]], "font" => ["bold" => true, "size" => 8]]);
            $fila++;

            foreach ($lineas as $i => $ln) {
                $sheet->setCellValue("A{$fila}", $ln["fecha"]);
                $sheet->setCellValue("B{$fila}", $ln["tipo"] === 1 ? "INGRESO" : "SALIDA");
                $sheet->setCellValue("C{$fila}", ($ln["motivo"] ?? "") . ($ln["tipo_referencia"] ? " [" . $ln["tipo_referencia"] . "]" : ""));
                if ($ln["entrada_cant"] !== null) {
                    $sheet->setCellValue("D{$fila}", (float) $ln["entrada_cant"]);
                    $sheet->setCellValue("E{$fila}", (float) $ln["entrada_cu"]);
                    $sheet->setCellValue("F{$fila}", (float) $ln["entrada_total"]);
                }
                if ($ln["salida_cant"] !== null) {
                    $sheet->setCellValue("G{$fila}", (float) $ln["salida_cant"]);
                    $sheet->setCellValue("H{$fila}", (float) $ln["salida_cu"]);
                    $sheet->setCellValue("I{$fila}", (float) $ln["salida_total"]);
                }
                $sheet->setCellValue("J{$fila}", (float) $ln["saldo_cant"]);
                $sheet->setCellValue("K{$fila}", (float) $ln["saldo_valor"]);
                $sheet->getStyle("A{$fila}:K{$fila}")->applyFromArray($estiloBorde);
                if ($i % 2 === 0) {
                    $sheet->getStyle("A{$fila}:K{$fila}")->getFill()
                        ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                        ->getStartColor()->setARGB("FFF5F7FA");
                }
                $fila++;
            }

            if ($totales) {
                $sheet->setCellValue("C{$fila}", "TOTALES DEL PERIODO");
                $sheet->setCellValue("D{$fila}", (float) $totales["entrada_cant"]);
                $sheet->setCellValue("F{$fila}", (float) $totales["entrada_valor"]);
                $sheet->setCellValue("G{$fila}", (float) $totales["salida_cant"]);
                $sheet->setCellValue("I{$fila}", (float) $totales["salida_valor"]);
                $sheet->setCellValue("J{$fila}", (float) $totales["saldo_cant"]);
                $sheet->setCellValue("K{$fila}", (float) $totales["saldo_valor"]);
                $sheet->getStyle("A{$fila}:K{$fila}")->applyFromArray([
                    "fill" => ["fillType" => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, "startColor" => ["argb" => $navy]],
                    "font" => ["bold" => true, "color" => ["argb" => $white], "size" => 8],
                ]);
            }

            foreach (["A" => 12, "B" => 12, "C" => 42, "D" => 10, "E" => 12, "F" => 14,
                      "G" => 10, "H" => 12, "I" => 14, "J" => 12, "K" => 14] as $col => $w) {
                $sheet->getColumnDimension($col)->setWidth($w);
            }
            $sheet->getStyle("D6:D{$fila}")->getNumberFormat()->setFormatCode("#,##0.0000");
            $sheet->getStyle("G6:G{$fila}")->getNumberFormat()->setFormatCode("#,##0.0000");
            $sheet->getStyle("J6:J{$fila}")->getNumberFormat()->setFormatCode("#,##0.0000");
            foreach (["E","F","H","I","K"] as $col) {
                $sheet->getStyle("{$col}6:{$col}{$fila}")->getNumberFormat()->setFormatCode("\"S/ \"#,##0.00");
            }

            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            header("Content-Disposition: attachment;filename=\"Kardex-" . date("Ymd") . ".xlsx\"");
            header("Cache-Control: max-age=0");
            $writer->save("php://output");
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>alert('Error al generar el Excel.'); window.history.back();</script>";
        }
    }

    private function calcularKardex(int $idPro, ?string $desde, ?string $hasta, ?int $idEmpresa, ?int $idSucursal): array
    {
        $DB = \Illuminate\Support\Facades\DB::class;

        $qSaldo = \Illuminate\Support\Facades\DB::table("movimientos_productos as mp")
            ->join("movimientos_productos_detalle as mpd", "mpd.id_movimientos_productos", "=", "mp.id_movimientos_productos")
            ->where("mpd.id_pro", $idPro)
            ->where("mp.movimientos_productos_estado", 1);
        if ($desde) $qSaldo->where("mp.movimientos_productos_fecha", "<", $desde);
        if ($idSucursal > 0) {
            $qSaldo->where("mp.id_sucursal", $idSucursal);
        } elseif ($idEmpresa) {
            $qSaldo->join("sucursals as s0", "s0.id_sucursal", "=", "mp.id_sucursal")->where("s0.id_empresa", $idEmpresa);
        }
        $saldoRow = $qSaldo->selectRaw("
            SUM(CASE WHEN mp.movimientos_productos_tipo=1 THEN CAST(mpd.movimientos_productos_detalle_cantidad AS DECIMAL(14,4)) ELSE 0 END)
          - SUM(CASE WHEN mp.movimientos_productos_tipo=2 THEN CAST(mpd.movimientos_productos_detalle_cantidad AS DECIMAL(14,4)) ELSE 0 END) as saldo_cantidad,
            SUM(CASE WHEN mp.movimientos_productos_tipo=1 THEN CAST(mpd.movimientos_productos_detalle_cantidad AS DECIMAL(14,4)) * mpd.costo_unitario ELSE 0 END)
          - SUM(CASE WHEN mp.movimientos_productos_tipo=2 THEN CAST(mpd.movimientos_productos_detalle_cantidad AS DECIMAL(14,4)) * mpd.costo_unitario ELSE 0 END) as saldo_valor
        ")->first();
        $saldoCant  = (float)($saldoRow->saldo_cantidad ?? 0);
        $saldoValor = (float)($saldoRow->saldo_valor    ?? 0);
        $saldoInicial = ["cantidad" => $saldoCant, "valor" => $saldoValor];

        $qMov = \Illuminate\Support\Facades\DB::table("movimientos_productos as mp")
            ->join("movimientos_productos_detalle as mpd", "mpd.id_movimientos_productos", "=", "mp.id_movimientos_productos")
            ->join("users as u", "u.id_users", "=", "mp.id_users")
            ->where("mpd.id_pro", $idPro)
            ->where("mp.movimientos_productos_estado", 1);
        if ($desde && $hasta) $qMov->whereBetween("mp.movimientos_productos_fecha", [$desde, $hasta]);
        if ($idSucursal > 0) {
            $qMov->where("mp.id_sucursal", $idSucursal);
        } elseif ($idEmpresa) {
            $qMov->join("sucursals as s1", "s1.id_sucursal", "=", "mp.id_sucursal")->where("s1.id_empresa", $idEmpresa);
        }
        $movimientos = $qMov->select(
                "mp.movimientos_productos_fecha as fecha",
                "mp.id_movimientos_productos",
                "mp.movimientos_productos_tipo as tipo",
                "mp.movimientos_productos_motivo as motivo",
                "mpd.movimientos_productos_detalle_cantidad as cantidad",
                "mpd.costo_unitario",
                "mpd.tipo_referencia",
                "u.nombre_users as usuario"
            )
            ->orderBy("mp.movimientos_productos_fecha")
            ->orderBy("mp.id_movimientos_productos")
            ->get();

        $totalECant = $totalEValor = $totalSCant = $totalSValor = 0.0;
        $lineas = [];
        foreach ($movimientos as $mov) {
            $cant  = (float) $mov->cantidad;
            $cu    = (float) $mov->costo_unitario;
            $total = $cant * $cu;
            if ((int)$mov->tipo === 1) {
                $saldoCant  += $cant;  $saldoValor  += $total;
                $totalECant += $cant;  $totalEValor += $total;
                $lineas[] = ["fecha" => $mov->fecha, "tipo" => 1, "motivo" => $mov->motivo,
                    "tipo_referencia" => $mov->tipo_referencia, "usuario" => $mov->usuario,
                    "entrada_cant" => $cant, "entrada_cu" => $cu, "entrada_total" => $total,
                    "salida_cant" => null, "salida_cu" => null, "salida_total" => null,
                    "saldo_cant" => $saldoCant, "saldo_valor" => $saldoValor];
            } else {
                $saldoCant  -= $cant;  $saldoValor  -= $total;
                $totalSCant += $cant;  $totalSValor += $total;
                $lineas[] = ["fecha" => $mov->fecha, "tipo" => 2, "motivo" => $mov->motivo,
                    "tipo_referencia" => $mov->tipo_referencia, "usuario" => $mov->usuario,
                    "entrada_cant" => null, "entrada_cu" => null, "entrada_total" => null,
                    "salida_cant" => $cant, "salida_cu" => $cu, "salida_total" => $total,
                    "saldo_cant" => $saldoCant, "saldo_valor" => $saldoValor];
            }
        }
        $totales = ["entrada_cant" => $totalECant, "entrada_valor" => $totalEValor,
                    "salida_cant"  => $totalSCant,  "salida_valor"  => $totalSValor,
                    "saldo_cant"   => $saldoCant,   "saldo_valor"   => $saldoValor];

        return [$lineas, $saldoInicial, $totales];
    }

    // ── PDF Transferencia ─────────────────────────────────────────
    public function transferencia_pdf()
    {
        $id = $_GET['id'] ?? null;
        if (!$id) abort(404);

        $trf = DB::table('transferencias_stock as t')
            ->leftJoin('almacen as ao',  'ao.id_almacen', '=', 't.id_almacen_origen')
            ->leftJoin('tiendas as tor', 'tor.id_tienda', '=', 't.id_tienda_origen')
            ->leftJoin('tiendas as td',  'td.id_tienda',  '=', 't.id_tienda_destino')
            ->leftJoin('almacen as ad',  'ad.id_almacen', '=', 't.id_almacen_destino')
            ->leftJoin('empresa as eo',  'eo.id_empresa',  '=', 'ao.id_empresa')
            ->leftJoin('empresa as eo2', 'eo2.id_empresa', '=', 'tor.id_empresa')
            ->leftJoin('empresa as ed',  'ed.id_empresa',  '=', 'td.id_empresa')
            ->leftJoin('empresa as ead', 'ead.id_empresa', '=', 'ad.id_empresa')
            ->join('users as u',         'u.id_users',    '=', 't.id_users')
            ->select(
                't.*',
                DB::raw("CONCAT(COALESCE(ao.almacen_nombre, tor.tienda_nombre, '—'), IFNULL(CONCAT(' - ', COALESCE(eo.empresa_nombrecomercial, eo2.empresa_nombrecomercial)), '')) as origen_nombre"),
                DB::raw("COALESCE(ao.almacen_direccion, tor.tienda_direccion, '') as origen_direccion"),
                DB::raw("CONCAT(COALESCE(td.tienda_nombre, ad.almacen_nombre, '—'), IFNULL(CONCAT(' - ', COALESCE(ed.empresa_nombrecomercial, ead.empresa_nombrecomercial)), '')) as destino_nombre"),
                DB::raw("COALESCE(td.tienda_direccion, ad.almacen_direccion, '') as destino_direccion"),
                DB::raw('COALESCE(eo.id_empresa, eo2.id_empresa) as id_empresa_trf'),
                DB::raw('COALESCE(ed.empresa_ruc, ead.empresa_ruc, eo.empresa_ruc, eo2.empresa_ruc) as destino_ruc'),
                DB::raw('COALESCE(ed.empresa_razon_social, ead.empresa_razon_social, eo.empresa_razon_social, eo2.empresa_razon_social) as destino_razon_social'),
                'u.nombre_users',
            )
            ->where('t.id_transferencia', $id)->first();

        if (!$trf) abort(404);

        $emp = $trf->id_empresa_trf
            ? DB::table('empresa as e')
                ->leftJoin('ubigeo as ub', 'ub.id_ubigeo', '=', 'e.id_ubigeo')
                ->where('e.id_empresa', $trf->id_empresa_trf)
                ->select('e.*', 'ub.ubigeo_distrito', 'ub.ubigeo_provincia', 'ub.ubigeo_departamento')
                ->first()
            : null;

        $items = DB::table('transferencias_stock_detalle as d')
            ->join('productos as p', 'p.id_pro', '=', 'd.id_pro')
            ->where('d.id_transferencia', $id)
            ->select('p.pro_nombre', 'p.pro_codigo', 'd.detalle_cantidad', 'd.detalle_cantidad_recibida')
            ->get();

        // ── PDF setup ─────────────────────────────────────────────
        $pdf = new PDFBufeo('P', 'mm', 'A4');
        $pdf->SetMargins(12, 12, 12);
        $pdf->SetAutoPageBreak(true, 20);
        $pdf->AddPage();
        $pdf->AliasNbPages();

        $xL = 12;
        $W  = 186;

        // ═════════════════════════════════════════════════════════
        // BLOQUE HEADER
        // ═════════════════════════════════════════════════════════
        $headerH = 50;
        $leftW   = 112;
        $rightW  = 54;
        $xRight  = $xL + $W - $rightW;  // 12+186-54 = 144; 144+54 = 198 ✓
        $yTop    = 12;
        $rowH    = $headerH / 3;        // ≈ 16.67 mm cada fila del recuadro derecho

        // ── Recuadro derecho (bordes redondeados) ─────────────────
        $r = 3; // radio de esquinas en mm
        $pdf->SetDrawColor(0, 0, 0);
        $pdf->RoundedRect($xRight, $yTop, $rightW, $headerH, $r);
        $pdf->Line($xRight, $yTop + $rowH,     $xRight + $rightW, $yTop + $rowH);
        $pdf->Line($xRight, $yTop + $rowH * 2, $xRight + $rightW, $yTop + $rowH * 2);

        // Fondo gris en fila 2 (GUIA REMISION REMITENTE)
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Rect($xRight + 0.2, $yTop + $rowH + 0.2, $rightW - 0.4, $rowH - 0.4, 'F');

        $pdf->SetTextColor(0, 0, 0);

        // Fila 1: RUC
        $pdf->SetFont('Helvetica', 'B', 12);
        $pdf->SetXY($xRight, $yTop + ($rowH / 2) - 4);
        $pdf->Cell($rightW, 8, 'RUC ' . ($emp->empresa_ruc ?? ''), 0, 0, 'C');

        // Fila 2: GUIA REMISION REMITENTE
        $pdf->SetFont('Helvetica', 'B', 8);
        $pdf->SetXY($xRight, $yTop + $rowH + ($rowH / 2) - 3.5);
        $pdf->Cell($rightW, 7, 'GUIA REMISION REMITENTE', 0, 0, 'C');

        // Fila 3: número de transferencia
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->SetXY($xRight, $yTop + $rowH * 2 + ($rowH / 2) - 4);
        $pdf->Cell($rightW, 8, utf8_decode($trf->transferencia_numero), 0, 0, 'C');

        // ── Lado izquierdo: logo + giro + dirección ───────────────
        $logoW = 0;
        if ($emp && !empty($emp->empresa_foto)) {
            $logoPath = public_path($emp->empresa_foto);
            if (file_exists($logoPath)) {
                $pdf->Image($logoPath, $xL + 1, $yTop + 1, 42, 38); // ancho fijo 42mm, alto 38mm
                $logoW = 44; // 42mm + 2mm margen
            }
        }

        // Texto descriptivo centrado entre logo y recuadro derecho
        $centerX     = $xL + $logoW + 2;
        $centerW     = $xRight - $centerX - 2;
        $lineH       = 4.5;
        $giroLines   = [
            'VENTA DE PARLANTES, USB, CARGADORES, COCINAS, PLATOS,',
            'PARAGUAS, PATINES, BICICLETAS, CORREAS, ARTICULOS DIVERSOS',
            'Y FERRETERIA EN GENERAL AL POR MAYOR Y MENOR',
        ];
        $blockH  = count($giroLines) * $lineH;
        $centerY = $yTop + 10;
        $pdf->SetFont('Helvetica', 'BI', 6);
        $pdf->SetTextColor(0, 0, 0);
        foreach ($giroLines as $i => $line) {
            $pdf->SetXY($centerX, $centerY + $i * $lineH);
            $pdf->Cell($centerW, $lineH, $line, 0, 0, 'C');
        }

        // Dirección, teléfonos, ciudad – alineados bajo el texto descriptivo
        $pdf->SetFont('Helvetica', 'BI', 6);
        $pdf->SetTextColor(0, 0, 0);
        $addrY = $yTop + ($headerH / 2) + 2;

        $domicilio = utf8_decode($emp->empresa_domiciliofiscal ?? '');
        if ($domicilio) {
            $pdf->SetXY($centerX, $addrY);
            $pdf->Cell($centerW, 4, $domicilio, 0, 1, 'C');
            $addrY += 4;
        }

        $tel1 = $emp->empresa_telefono1 ?? '';
        $tel2 = $emp->empresa_telefono2 ?? '';
        $phone = trim($tel1 . ($tel2 ? ' - ' . $tel2 : ''));
        if ($phone) {
            $pdf->SetXY($centerX, $addrY);
            $pdf->Cell($centerW, 4, $phone, 0, 1, 'C');
            $addrY += 4;
        }

        $cityParts = array_filter([
            $emp->ubigeo_distrito    ?? '',
            $emp->ubigeo_provincia   ?? '',
            $emp->ubigeo_departamento ?? '',
        ]);
        if ($cityParts) {
            $pdf->SetXY($centerX, $addrY);
            $pdf->Cell($centerW, 4, utf8_decode(implode(' - ', $cityParts)), 0, 1, 'C');
        }


        // ═════════════════════════════════════════════════════════
        // DESTINATARIO
        // ═════════════════════════════════════════════════════════
        $yDest = $yTop + $headerH + 5;
        $pdf->SetTextColor(0, 0, 0);

        $pdf->SetXY($xL, $yDest);
        $pdf->SetFont('Helvetica', 'B', 10);
        $pdf->Cell(32, 6, 'DESTINATARIO:', 0, 0);
        $pdf->SetFont('Helvetica', '', 10);
        $pdf->Cell($W - 32, 6, utf8_decode(mb_strtoupper($trf->destino_razon_social ?? $trf->destino_nombre ?? '')), 0, 1);

        $pdf->SetXY($xL, $yDest + 7);
        $pdf->SetFont('Helvetica', 'B', 10);
        $pdf->Cell(14, 6, 'RUC:', 0, 0);
        $pdf->SetFont('Helvetica', '', 10);
        $pdf->Cell($W - 14, 6, $trf->destino_ruc ?? '', 0, 1);

        // ═════════════════════════════════════════════════════════
        // TABLA DE INFO: Fecha | Punto Partida | Punto Llegada | Motivo
        // ═════════════════════════════════════════════════════════
        $yInfo     = $yDest + 16;
        $infoCols  = [36, 50, 50, 50];   // 186 mm total

        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->SetXY($xL, $yInfo);
        foreach (['Fecha Traslado', 'Punto Partida', 'Punto Llegada', 'Motivo'] as $i => $h) {
            $pdf->Cell($infoCols[$i], 7, $h, 1, 0, 'C');
        }
        $pdf->Ln();

        $fechaStr = date('d-m-Y H:i', strtotime($trf->transferencia_fecha));
        $partida  = utf8_decode(mb_substr(mb_strtoupper($trf->origen_nombre  ?? ''), 0, 60));
        $llegada  = utf8_decode(mb_substr(mb_strtoupper($trf->destino_nombre ?? ''), 0, 60));
        $motivo   = utf8_decode($trf->transferencia_motivo ?: 'Traslado entre establecimientos de la misma empresa');

        $pdf->SetFont('Helvetica', '', 7);
        $pdf->SetWidths($infoCols);
        $pdf->aligns = ['C', 'L', 'L', 'L'];
        $pdf->SetX($xL);
        $pdf->Row_([$fechaStr, $partida, $llegada, $motivo]);

        // ═════════════════════════════════════════════════════════
        // TABLA DE PRODUCTOS
        // ═════════════════════════════════════════════════════════
        $yProd    = $pdf->GetY() + 4;
        $prodCols = [10, 26, 92, 26, 32];  // N° | CODIGO | DESCRIPCIÓN | CANTIDAD | UNIDAD

        $pdf->SetFillColor(50, 50, 50);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->SetXY($xL, $yProd);
        foreach ([utf8_decode('N°'), utf8_decode('CÓDIGO'), utf8_decode('DESCRIPCIÓN'), 'CANTIDAD', 'UNIDAD DE DESPACHO'] as $i => $h) {
            $pdf->Cell($prodCols[$i], 8, $h, 1, 0, $i === 2 ? 'L' : 'C', true);
        }
        $pdf->Ln();

        $pdf->SetTextColor(0, 0, 0);
        $fill = false;
        foreach ($items as $idx => $item) {
            $pdf->CheckPageBreak(7);
            $bg = $fill ? 242 : 255;
            $pdf->SetFillColor($bg, $bg, $bg);
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell($prodCols[0], 6, $idx + 1,                                                  'B', 0, 'C',  $fill);
            $pdf->Cell($prodCols[1], 6, $item->pro_codigo ?? '',                                    'B', 0, 'C',  $fill);
            $pdf->Cell($prodCols[2], 6, utf8_decode(mb_substr($item->pro_nombre, 0, 50)),           'B', 0, 'L',  $fill);
            $pdf->Cell($prodCols[3], 6, number_format((float) $item->detalle_cantidad, 2),          'B', 0, 'C',  $fill);
            $pdf->Cell($prodCols[4], 6, 'Unidad',                                                   'B', 0, 'C',  $fill);
            $pdf->Ln();
            $fill = !$fill;
        }

        // ═════════════════════════════════════════════════════════
        // RECUADRO TRANSPORTE / CONFORMIDAD
        // ═════════════════════════════════════════════════════════
        $boxH  = 42;
        $colW  = round($W / 3, 2); // 62 mm
        $pdf->CheckPageBreak($boxH + 14);
        $yBox  = $pdf->GetY() + 5;

        $pdf->SetDrawColor(0, 0, 0);
        $pdf->Rect($xL, $yBox, $W, $boxH);
        $pdf->Line($xL + $colW,     $yBox, $xL + $colW,     $yBox + $boxH);
        $pdf->Line($xL + $colW * 2, $yBox, $xL + $colW * 2, $yBox + $boxH);

        // Columna 1: Unidad de Transporte
        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetXY($xL + 2, $yBox + 2);
        $pdf->Cell($colW - 4, 5, 'Unidad de Transporte Conductor', 0, 1);
        $pdf->SetFont('Helvetica', '', 7);
        $y1 = $yBox + 8;
        foreach (['Conductor:', 'DNI del Conductor:', 'Placa del Vehiculo:', 'Licencia:'] as $lbl) {
            $pdf->SetXY($xL + 2, $y1);
            $pdf->Cell($colW - 4, 5.5, $lbl, 0, 1);
            $y1 += 5.5;
        }

        // Columna 2: Modalidad
        $x2 = $xL + $colW + 2;
        $y2 = $yBox + 3;
        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->SetXY($x2, $y2);
        $pdf->Cell(38, 5, 'Modalidad de Transporte:', 0, 0);
        $pdf->SetFont('Helvetica', '', 7);
        $pdf->Cell($colW - 42, 5, utf8_decode('Público'), 0, 1);

        $y2 += 6;
        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->SetXY($x2, $y2);
        $pdf->Cell($colW - 4, 5, 'Cantidad Bultos:', 0, 1);

        // Columna 3: Nombre / DNI / Conformidad
        $x3 = $xL + $colW * 2 + 2;
        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->SetXY($x3, $yBox + 3);
        $pdf->Cell($colW - 4, 5, 'Nombre:', 0, 1);
        $pdf->SetXY($x3, $yBox + 9);
        $pdf->Cell($colW - 4, 5, 'DNI:', 0, 1);

        $pdf->SetFont('Helvetica', 'B', 8);
        $pdf->SetXY($x3, $yBox + 25);
        $pdf->Cell($colW - 4, 5, 'CONFORMIDAD', 0, 0, 'C');

        // Línea de firma
        $sigY = $yBox + 32;
        $pdf->Line($x3 + 4, $sigY, $x3 + $colW - 8, $sigY);

        // ═════════════════════════════════════════════════════════
        // TEXTO FINAL AMAZONIA
        // ═════════════════════════════════════════════════════════
        $yFoot = $yBox + $boxH + 4;
        $pdf->SetFont('Helvetica', '', 7);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetXY($xL, $yFoot);
        $pdf->Cell($W, 4, '"BIENES TRANSFERIDOS EN LA AMAZONIA PARA SER CONSUMIDOS EN LA MISMA."', 0, 1);
        $pdf->SetX($xL);
        $pdf->Cell($W, 4, '"SERVICIOS PRESTADOS EN LA AMAZONIA"', 0, 0);

        $filename = 'Guia-Remision-' . $trf->transferencia_numero . '.pdf';
        while (ob_get_level() > 0) ob_end_clean();
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $filename . '"');
        echo $pdf->Output('S', $filename);
        exit;
    }

}