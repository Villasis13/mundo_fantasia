<?php

namespace App\Http\Controllers;

use App\Mail\ComprobanteCorreo;
use App\Models\Caja;
use App\Models\Cliente;
use App\Models\Empresa;
use App\Models\General;
use App\Models\Logs;
use App\Models\Movimientos_productos;
use App\Models\PDFBufeo;
use App\Models\Productos;
use App\Models\Proforma;
use App\Models\Serie;
use App\Models\Submenu;
use App\Models\Tipo_documento;
use App\Models\Tipo_ncredito;
use App\Models\Tipo_ndebito;
use App\Models\Tipo_pago;
use App\Models\Ventas;
use App\Models\Ventas_detalle_pago;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Luecano\NumeroALetras\NumeroALetras;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class GestionventasController extends Controller
{
    private $submenu;
    private $logs;
    private $general;
    private $productos;
    private $tipo_pago;
    private $empresa;
    private  $movimeinto_producto;
    private $caja;
    private $clientes;
    private $tipo_documento;
    private $serie;
    private  $venta;
    private $proforma;

    public function __construct()
    {
        $this->submenu = new Submenu();
        $this->logs = new Logs();
        $this->general = new General();
        $this->productos = new Productos();
        $this->tipo_pago = new Tipo_pago();
        $this->empresa = new Empresa();
        $this->caja = new Caja();
        $this->movimeinto_producto =  new Movimientos_productos();
        $this->clientes =  new Cliente();
        $this->tipo_documento =  new Tipo_documento();
        $this->serie =  new Serie();
        $this->venta = new Ventas();
        $this->proforma = new Proforma();
    }


    public function movimientos()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("movimientos");
            return view('gestionventas/movimientos', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }
    public function proformas()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("proformas");
            return view('gestionventas/proformas', compact('opciones'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }

    public function realizar_ventas()
    {
        try {

            $opciones = $this->submenu->optiones_por_vista("realizar_ventas");

            return view('gestionventas/realizar_venta', compact('opciones'));
        }catch (\Exception $e){
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }
    public function registro_pagos()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("registro_pagos");
            return view('gestionventas.registro_pagos', compact('opciones'));
        }catch (\Exception $e){
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }
    public function notas_de_venta()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("notas_de_venta");
            return view('gestionventas.notas_de_venta', compact('opciones'));
        }catch (\Exception $e){
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }

    public function venta_detalle()
    {
        try {
            $ventaId = (int)request()->get('venta_id');
            $opciones = $this->submenu->optiones_por_vista("venta_detalle");
            return view('gestionventas/venta_detalle', compact('opciones', 'ventaId'));
        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            echo "<script>
                alert(\"Error Al Mostrar Contenido. Redireccionando Al Inicio\");
                window.location.href = '" . route('admin') . "';
            </script>";
        }
    }


    public function imprimir_proforma(){
        $id = $_GET['data'];
        $id_proforma = (int)$id;
        if($id_proforma){
            $guardar_localmente = true;
            $ruta_guardado = "";

            $proforma =  $this->proforma->listar_proforma_x_id($id_proforma);
            $detalle =  $this->proforma->listar_detalle_x_id($id_proforma);
            $empresa =  DB::table('empresa')
                ->where('id_empresa','=',1)->first();


            $pdf = new PDFBufeo('P');
            $pdf->AddPage();
            //CABECERA DEL ARCHIVO
            if (file_exists($empresa->empresa_foto_ticket)) {
                $pdf->Image("$empresa->empresa_foto_ticket", 10, 10, 30,30);
            }
            $pdf->Ln(5);
            $pdf->SetFillColor(220,220,220);
            $pdf->SetFont('Arial','B',14);
            // FILA 1
            $pdf->Cell(35,6,'',0,0,'');
            $pdf->Cell(95,6,$empresa->empresa_razon_social,0,0,1);
            $pdf->Cell(50,0,'','T',1,'R');
            // FILA 2
            $pdf->SetFont('Arial','',10);
            $pdf->Cell(130,6,'',0,0,1);
            $pdf->Cell(50,8, "RUC: $empresa->empresa_ruc",0,1,'C',0);
            // FILA 3
//            $pdf->SetFillColor(231,193,201);
            $pdf->SetFillColor(192,54,97);
            if (file_exists('home.png')) {
                $pdf->Image("home.png", 45, 24, 4,4);
            }
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(35,6,'',0,0,'');
            $pdf->Cell(95,6,utf8_decode("$empresa->empresa_domiciliofiscal"),0,0,'L',0);
            $pdf->SetTextColor(255,255,255);
            $pdf->SetFont('Arial','B',10);
            $pdf->Cell(50,8,utf8_decode('COTIZACIÓN'),0,1,'C',1);
            $pdf->SetFillColor(220,220,220);
            $pdf->SetTextColor(0,0,0);
            $pdf->SetFont('Arial','',10);
            // FILA 4
            $pdf->Cell(35,4,'',0,0,'');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(95,0.5,utf8_decode("$empresa->empresa_telefono1  /  $empresa->empresa_telefono2  "),0,0,'L',0);
            $pdf->SetFont('Arial','',10);
            $pdf->Cell(50,8,"$proforma->profo_serie - 0$proforma->profo_correlativo",0,1,'C',0);
            // FILA 5
            $pdf->Cell(35,4,'',0,0);
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(95,-6,utf8_decode("$empresa->empresa_correo"),0,0,'L',0);
            $pdf->Cell(50,0,'','T',1,'R');

            $pdf->Ln(5);
            $pdf->SetFillColor(192,54,97);

            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            //
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(18,5,utf8_decode("SEÑORES :"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(97,5,utf8_decode("$proforma->cliente_razonsocial"),0,0,'L');
            $fecha = date('d/m/Y',strtotime($proforma->profo_fecha_emision));
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("FECHA :"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("$fecha"),0,1,'L');
            //
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(18,5,utf8_decode("DIRECCIÓN :"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(97,5,utf8_decode("$proforma->cliente_direccion"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("MONEDA :"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("SOLES"),0,1,'L');
            //
            if ($proforma->id_tipo_documento == 2){
                $documento = 'DNI:';
            }else{
                $documento = 'RUC:';
            }
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(18,5,utf8_decode("$documento"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(32,5,utf8_decode("$proforma->cliente_numero"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(20,5,utf8_decode("TELÉFONO:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(45,5,utf8_decode("$proforma->cliente_telefono"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("REFERENCIA:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode(""),0,1,'L');
            //
            if ($proforma->profo_forma_pago == 1){
                $forma_pago = "CONTADO";
            }else{
                $forma_pago = 'CREDITO';
            }
            $pdf->SetFont('Arial','B',7);
//            $pdf->Cell(20,5,utf8_decode("ATENCIÓN:"),0,0,'L');
            $pdf->Cell(20,5,utf8_decode(""),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(30,5,utf8_decode(""),0,0,'L');
//            $pdf->Cell(30,5,utf8_decode("$proforma->nombre_users"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
//            $pdf->Cell(20,5,utf8_decode("CORREO:"),0,0,'L');
            $pdf->Cell(20,5,utf8_decode(""),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(45,5,utf8_decode(""),0,0,'L');
//            $pdf->Cell(45,5,utf8_decode("karenpamela@emyspets.com"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("FORMA DE PAGO:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("$forma_pago"),0,1,'L');
            $pdf->Ln(3);
            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            //
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(30,5,utf8_decode("LUGAR DE ENTREGA:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(85,5,utf8_decode("$proforma->profo_lugar_entrega"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("VENDEDOR:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("$proforma->nombre_users"),0,1,'L');
            //
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(30,5,utf8_decode("OBSERVACIONES:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(85,5,utf8_decode("$proforma->profo_observacion"),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("CARGO:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("Dep de Ventas"),0,1,'L');
            //
            $pdf->Cell(115,5,utf8_decode(""),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("CORREO:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("$proforma->email"),0,1,'L');
            //
            $pdf->Cell(115,5,utf8_decode(""),0,0,'L');
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(25,5,utf8_decode("TELÉFONO:"),0,0,'L');
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(25,5,utf8_decode("$proforma->persona_telefono"),0,1,'L');
            $pdf->Ln(3);
            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            //COLUMNAS
            $pdf->SetFont('Helvetica','B',7);
            $pdf->SetTextColor(255,255,255);
            $pdf->Cell(10, 6, 'ITEM', 1,'','C',1);
            $pdf->Cell(25, 6, utf8_decode("CÓDIGO"),1,0,'C',1);
            $pdf->Cell(90, 6, utf8_decode('DESCRIPCIÓN'), 1,'','C',1);
            $pdf->Cell(15, 6, 'CANT',1,0,'C',1);
            $pdf->Cell(20, 6, 'PRECIO',1,0,'C',1);
            $pdf->Cell(20, 6, 'TOTAL',1,1,'C',1);
            $pdf->Ln(2);
            $pdf->SetTextColor(0,0,0);
            //PRODUCTOS
            $pdf->SetWidths(array(10,25,90,15,20,20));
            $aa=1;
            $filas_tot = 0;
            $total_proforma = 0;
            foreach ($detalle as $f){
                $pdf->SetFont('Helvetica', '', 7);
                $desc =  $f->profo_deta_observacion ? utf8_decode(": $f->profo_deta_observacion") : '';
                $nombre = utf8_decode("$f->pro_nombre $desc");
                $pdf->Row(array($aa,$f->pro_codigo, $nombre,  number_format(round("$f->profo_deta_cantidad",2), 2, '.', ' '),  number_format(round("$f->profo_deta_precio",2), 2, '.', ' '),number_format(round($f->profo_deta_precio * $f->profo_deta_cantidad,2), 2, '.', ' ')));
                $cant = strlen($nombre);
                $filas = ceil($cant / 65);
                if($filas==0){$filas=1;}
                $filas_tot+=$filas;
                $he = 4 * $filas;
                $aa++;
                $total_proforma += (float)$f->profo_deta_precio * (float)$f->profo_deta_cantidad;

            }
            $pdf->Ln(5);
            $da = new NumeroALetras();
            $importe_letra = $da->toInvoice($total_proforma,'2','soles');
//            $pdf->Cell(70, 3, "$importe_letra", 0,0,'L');
            $pdf->Ln(5);
            $pdf->Cell(105,20,utf8_decode("$importe_letra"),1,0,'C');
            $pdf->SetTextColor(255,255,255);
            $pdf->SetFont('Arial','B',8);
            $pdf->Cell(45,20,utf8_decode("TOTAL GENERAL"),1,0,'C',1);
            $pdf->SetTextColor(0,0,0);
            $pdf->SetFont('Arial','',8);
            $pdf->Cell(30,20,"S/ ".number_format(round($total_proforma,2), 2, '.', ' '),1,1,'C');
            $pdf->SetFont('Arial','',6);
            $pdf->Ln(2);
            $pdf->Cell(180,4,utf8_decode("Sistema de Géstion Administrativa, Desarrollado por Bufeo Innovacion Tecnologica S.a.c. | Whatsapp 925812998 | E-mail: bufeotec@gmail.com"),0,0,'C');

            if(isset($guardar_localmente) && isset($ruta_guardado)){

//                $ruta_guardado = 'comprobantes/'.date('Y-m-d').'.pdf';
                $ruta_guardado = "Proforma-$proforma->profo_serie-0$proforma->profo_correlativo".'.pdf';
                $pdf->Output("I",$ruta_guardado);
            } else {
                $pdf->Output('',"proformas-" .date('Y-m-d'));
            }
            exit;

        }
    }
    public function imprimir_ticket_pdf(){
        $id = $_GET['venta_id'];
        $id_venta = (int)$id;
        if($id_venta){
            $guardar_localmente = true;
            $ruta_guardado = "";
            $dato_venta = $this->venta->listar_venta_x_id_pdf($id_venta);
            $detalle_venta = $this->venta->listar_venta_detalle_x_id_venta_pdf($id_venta);
            $formas_de_pago = Ventas_detalle_pago::listar_formas_x_idventa($id_venta);
            $formas_de_pago_mensaje = collect($formas_de_pago)->pluck('tipo_pago_nombre')->filter()->implode(' - ');

            $empresa = $this->empresa->listar_datos_empresa();
            $ruta_qr = $this->general->generar_qr($dato_venta->id_venta);
            $dnni = "";
            if ($dato_venta->venta_tipo == "03") {
                $tipo_comprobante = "BOLETA DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DNI';
                $documento = $dato_venta->cliente_numero;
            } else if ($dato_venta->venta_tipo == "01") {
                $tipo_comprobante = "FACTURA DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'RUC';
                $documento = $dato_venta->cliente_numero;
            } else if ($dato_venta->venta_tipo == "07") {
                $tipo_comprobante = "NOTA DE CRÉDITO DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DOCUMENTO';
                $documento = "$dato_venta->cliente_numero";
            } else if($dato_venta->venta_tipo == "08") {
                $tipo_comprobante = "NOTA DE DÉBITO DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DOCUMENTO';
                $documento = "$dato_venta->cliente_numero";
            }else if($dato_venta->venta_tipo == "20") {
                $tipo_comprobante = "NOTA DE VENTA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DOCUMENTO';
                $documento = "$dato_venta->cliente_numero";
            }
            $da = new NumeroALetras();
            $importe_letra = $da->toInvoice($dato_venta->venta_total,'2','soles');


            $pdf = new PDFBufeo('P');
            $pdf->AddPage();
            //CABECERA DEL ARCHIVO
            if (file_exists($dato_venta->empresa_foto_ticket)) {
                $pdf->Image("$dato_venta->empresa_foto_ticket", config('services.pdf.izq_logo_a4'), 10, config('services.pdf.ancho'),config('services.pdf.alto'));
            }
            $pdf->Ln(5);
            $pdf->SetFillColor(220,220,220);
            $pdf->SetFont('Helvetica','',9);
            $pdf->Cell(105,0,'','',0);
            $pdf->Cell(75,0,'','T',1,'R');
            $pdf->Cell(158,8, "RUC $dato_venta->empresa_ruc",0,1,'R',0);
            $pdf->Cell(105,8,"",0,0,'R',0);
            $pdf->Cell(75,8,utf8_decode($tipo_comprobante),0,1,'C',1);
            $pdf->Cell(150,8,"$serie_correlativo",0,1,'R',0);
            $pdf->Cell(105,0,'','',0);
            $pdf->Cell(75,0,'','T',1,'R');
            $pdf->SetFont('Helvetica','B',9);
            $pdf->MultiAlignCell(105,4,utf8_decode($dato_venta->empresa_razon_social),0,1,'C');
            $pdf->SetFont('Helvetica','',7);
            $pdf->Cell(105,4,utf8_decode($dato_venta->empresa_domiciliofiscal),0,0,'C');
            $pdf->Cell(75,4,utf8_decode("Fecha y hora de impresión: ".date('d/m/Y H:i:s')),0,1,'C');
            $pdf->Ln(3);
            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(16,4, "Fecha:",0,0,'L',false);
            $pdf->SetFont('Helvetica','',8);
            $pdf->Cell(35,4, date('d/m/Y H:i:s',strtotime($dato_venta->venta_fecha)),0,0,'L',false);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(25,4, "Registrado Por:",0,0,'L',false);
            $pdf->SetFont('Helvetica','',8);
            $pdf->Cell(40,4, utf8_decode($dato_venta->nombre_users),0,0,'L',false);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(22,4, $dato_venta->id_formas_pago == 1 ? "Pago:" : utf8_decode("Total de cuotas:"),0,0,'L',false);
            $pdf->SetFont('Helvetica','',8);
            if ($dato_venta->id_formas_pago == 2){
                $dato_cuotas = $this->venta->listar_cuotas($id);
                $formas_de_pago_mensaje  = count($dato_cuotas);
            }
            $pdf->Cell(42,4,  utf8_decode($formas_de_pago_mensaje),0,1,'L',false);
            $pdf->Ln(1);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(22,4,"$dnni:",0,0,'L');
            $pdf->SetFont('Helvetica','',8);
            $pdf->Cell(30,4, "$documento",0,0,'L',false);
            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(14,4,"Cliente:",0,0,'L');
            if($dato_venta->id_tipo_documento != 4){
                $pdf->SetFont('Helvetica','',7);
                $pdf->MultiAlignCell(115,4, utf8_decode($dato_venta->cliente_nombre),0,1,'L',false);
            }else{
                $pdf->SetFont('Helvetica','',7);
                $pdf->MultiAlignCell(115,4, utf8_decode($dato_venta->cliente_razonsocial),0,1,'L',false);
            }

            $pdf->Ln(1);

            $pdf->SetFillColor(180,180,180);
            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(16,4,utf8_decode('Dirección:'),0,0,'L');
            $pdf->SetFont('Helvetica','',8);
            $direccionCliente = isset($dato_venta->cliente_direccion) ? $dato_venta->cliente_direccion : '-';
            $pdf->MultiCell(165,4,utf8_decode($direccionCliente),0,1,'');

            $pdf->Ln(1);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(26,4,"Forma de pago:",0,0,'L');
            $pdf->SetFont('Helvetica','',7);
            $pdf->Cell(14,4,utf8_decode($dato_venta->id_formas_pago == 1 ? 'CONTADO' : 'CRÉDITO'),0,1,'L');
            if ((int)$dato_venta->id_formas_pago === 2) {
                $dato_cuotas = $this->venta->listar_cuotas($id);

                $cuotasTxt = [];
                $i = 1;

                foreach ($dato_cuotas as $da) {
                    $nro = str_pad((string)$i, 3, '0', STR_PAD_LEFT);
                    $fecha = date('d-m-Y', strtotime($da->venta_cuota_fecha));
                    $importe = number_format((float)$da->venta_cuota_importe, 2, '.', '');

                    $cuotasTxt[] = "Cuota {$nro}: {$fecha} ({$dato_venta->simbolo} {$importe})";
                    $i++;
                }
                $pdf->SetFont('Helvetica', '', 6);
                $pdf->MultiAlignCell(180, 4, implode('  -  ', $cuotasTxt), 0, 1, 'L');
            }
            if ($dato_venta->tipo_documento_modificar) {

                if ($dato_venta->venta_tipo == "07") {
                    $datos = Tipo_ncredito::listar_tipo_notaC_x_codigo($dato_venta->venta_codigo_motivo_nota);
                } else {
                    $datos = Tipo_ndebito::listar_tipo_notaD_x_codigo($dato_venta->venta_codigo_motivo_nota);
                }

                $motivo = $datos->tipo_nota_descripcion ?? '-';
                $comprobanteAfectado = $dato_venta->tipo_documento_modificar == '03' ? 'BOLETA' : 'FACTURA';

                $pdf->Ln(2);

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(36, 4, utf8_decode("Comprobante afectado:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(20, 4, utf8_decode($comprobanteAfectado), 0, 0, 'L');

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(42, 4, utf8_decode("Serie del comprobante:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(18, 4, utf8_decode($dato_venta->serie_modificar ?? '-'), 0, 0, 'L');

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(46, 4, utf8_decode("Correlativo del comprobante:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(18, 4, utf8_decode($dato_venta->correlativo_modificar ?? '-'), 0, 1, 'L');

                $pdf->Ln(1);

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(30, 4, utf8_decode("Motivo de la nota:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(150, 4, utf8_decode($motivo), 0, 1, 'L');
            }
            $pdf->Ln(3);
            //COLUMNAS
            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            $pdf->SetFont('Helvetica','B',7);
            $pdf->Cell(8, 10, 'ITEM', 1,'','C',1);
            $pdf->Cell(10, 10, 'CANT',1,0,'C',1);
            $pdf->Cell(105, 10, utf8_decode('DESCRIPCIÓN'), 1,'','C',1);
            $pdf->Cell(20, 10, 'V.U.',1,0,'C',1);
            $pdf->Cell(20, 10, 'P.U.',1,0,'C',1);
            $pdf->Cell(17, 10, 'P.VENTA',1,1,'C',1);

            $pdf->SetWidths(array(8,10,105,20,20,17));
            $aa = 1;
            $filas_tot = 0;
            foreach ($detalle_venta as $f){
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Row(array($aa,$f->venta_detalle_cantidad, utf8_decode($f->venta_detalle_nombre_producto),  number_format(round("$f->venta_detalle_valor_unitario",2), 2, '.', ' '),  number_format(round("$f->venta_detalle_precio_unitario",2), 2, '.', ' '),number_format(round("$f->venta_detalle_importe_total",2), 2, '.', ' ')));
                $aa++;
            }
            $pdf->Ln(7);
            $pdf->Cell(80,3,'','T',0,'R');
            $pdf->Cell(60,0,'',0,0,'L');
            $pdf->Cell(40,3,'','T',1,'R');
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->Cell(70, 3, "$importe_letra", 0,0,'L');
            if ($dato_venta->venta_tipo != "20") {
                $pdf->Image("$ruta_qr", '8', $pdf->GetY() + 4, '20', '20', '', '');
            }
            $pdf->Ln(8);
            if($dato_venta->venta_tipo != "20"){
                $pdf->Cell(80,1,'BIENES TRANSFERIDOS PARA SU ',0,0,'R');
            }else{
                $pdf->Cell(80,1,'ESTE NO ES UN COMPROBANTE',0,0,'R');
            }

            $pdf->Cell(100, 1, "Op.Grat: $dato_venta->simbolo $dato_venta->venta_totalgratuita", 0,1,'R');
            $pdf->Ln(3);
            if($dato_venta->venta_tipo != "20"){
                $pdf->Cell(80,1,'CONSUMO EN EL TERRITORIO NACIONAL',0,0,'R');
            }else{
                $pdf->Cell(80,1,'VALIDO PARA SUNAT SI REQUIERE UNA',0,0,'R');
            }
            $pdf->Cell(100, 1, "Op.Exon: $dato_venta->simbolo $dato_venta->venta_totalexonerada", 0,1,'R');
            $pdf->Ln(3);
            if($dato_venta->venta_tipo != "20"){
                $pdf->Cell(80,1,'CONFORME A LA NORMATIVA VIGENTE',0,0,'R');
            }else{
                $pdf->Cell(80,1,utf8_decode('BOLETA O FACTURA, SOLICÍTALO'),0,0,'R');
            }
            $pdf->Cell(100, 1, "Op.Inaf: $dato_venta->simbolo $dato_venta->venta_totalinafecta", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "Op.Grav: $dato_venta->simbolo $dato_venta->venta_totalgravada", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "IGV: $dato_venta->simbolo $dato_venta->venta_totaligv", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "Pago con: $dato_venta->simbolo $dato_venta->venta_pago_cliente", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "Vuelto : $dato_venta->simbolo $dato_venta->venta_vuelto", 0,1,'R');
            $pdf->Ln(3);

            $pdf->Ln(5);
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell(70, 0, utf8_decode('ASSU Ventas | Tu aliado en facturación electrónica.'), 0, 0, 'L');
            $pdf->SetFont('Helvetica', 'B', 9);
            $pdf->Cell(110, 1, "TOTAL: $dato_venta->simbolo $dato_venta->venta_total", 0,'1','R');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Ln(3);
            $pdf->Cell(60,0,'',0,1,'L');
            $pdf->Ln(3);
            $pdf->Cell(80,3,'','T',0,'R');
            $pdf->Cell(60,0,'',0,0,'L');
            $pdf->Cell(40,3,'','T',1,'R');

            if(isset($guardar_localmente) && isset($ruta_guardado)){
                $ruta_guardado = 'comprobantes/'."$serie_correlativo-" .date('Y-m-d').'.pdf';
                $pdf->Output("I",$ruta_guardado);
            } else {
                $pdf->Output('',"$serie_correlativo-" .date('Y-m-d'));
            }
            exit;

        }
    }
    public function imprimir_ticket_pdf_local($id_ve){
        $id = $id_ve;
        $id_venta = (int)$id;
        if($id_venta){

            $dato_venta = $this->venta->listar_venta_x_id_pdf($id_venta);
            $detalle_venta = $this->venta->listar_venta_detalle_x_id_venta_pdf($id_venta);
            $formas_de_pago = Ventas_detalle_pago::listar_formas_x_idventa($id_venta);
            $formas_de_pago_mensaje = collect($formas_de_pago)->pluck('tipo_pago_nombre')->filter()->implode(' - ');

            $empresa = $this->empresa->listar_datos_empresa();
            $ruta_qr = $this->general->generar_qr($dato_venta->id_venta);

            $empresa = $this->empresa->listar_datos_empresa();
            $ruta_qr = $this->general->generar_qr($dato_venta->id_venta);
            $dnni = "";
            if ($dato_venta->venta_tipo == "03") {
                $tipo_comprobante = "BOLETA DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DNI';
                $documento = $dato_venta->cliente_numero;
            } else if ($dato_venta->venta_tipo == "01") {
                $tipo_comprobante = "FACTURA DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'RUC';
                $documento = $dato_venta->cliente_numero;
            } else if ($dato_venta->venta_tipo == "07") {
                $tipo_comprobante = "NOTA DE CRÉDITO DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DOCUMENTO';
                $documento = "$dato_venta->cliente_numero";
            } else if($dato_venta->venta_tipo == "08") {
                $tipo_comprobante = "NOTA DE DÉBITO DE VENTA ELECTRONICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DOCUMENTO';
                $documento = "$dato_venta->cliente_numero";
            }else if($dato_venta->venta_tipo == "20") {
                $tipo_comprobante = "NOTA DE VENTA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $dnni = 'DOCUMENTO';
                $documento = "$dato_venta->cliente_numero";
            }
            $da = new NumeroALetras();
            $importe_letra = $da->toInvoice($dato_venta->venta_total,'2','soles');

            $pdf = new PDFBufeo('P');
            $pdf->AddPage();
            //CABECERA DEL ARCHIVO
            if (file_exists($dato_venta->empresa_foto_ticket)) {
                $pdf->Image("$dato_venta->empresa_foto_ticket", config('services.pdf.izq_logo_a4'), 10, config('services.pdf.ancho'),config('services.pdf.alto'));
            }
            $pdf->Ln(5);
            $pdf->SetFillColor(220,220,220);
            $pdf->SetFont('Helvetica','',9);
            $pdf->Cell(105,0,'','',0);
            $pdf->Cell(75,0,'','T',1,'R');
            $pdf->Cell(158,8, "RUC $dato_venta->empresa_ruc",0,1,'R',0);
            $pdf->Cell(105,8,"",0,0,'R',0);
            $pdf->Cell(75,8,utf8_decode($tipo_comprobante),0,1,'C',1);
            $pdf->Cell(150,8,"$serie_correlativo",0,1,'R',0);
            $pdf->Cell(105,0,'','',0);
            $pdf->Cell(75,0,'','T',1,'R');
            $pdf->SetFont('Helvetica','B',9);
            $pdf->MultiAlignCell(105,4,utf8_decode($dato_venta->empresa_razon_social),0,1,'C');
            $pdf->SetFont('Helvetica','',7);
            $pdf->Cell(105,4,utf8_decode($dato_venta->empresa_domiciliofiscal),0,0,'C');
            $pdf->Cell(75,4,utf8_decode("Fecha y hora de impresión: ".date('d/m/Y H:i:s')),0,1,'C');
            $pdf->Ln(3);
            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(16,4, "Fecha:",0,0,'L',false);
            $pdf->SetFont('Helvetica','',8);
            $pdf->Cell(35,4, date('d/m/Y H:i:s',strtotime($dato_venta->venta_fecha)),0,0,'L',false);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(25,4, "Registrado Por:",0,0,'L',false);
            $pdf->SetFont('Helvetica','',8);
            $pdf->Cell(40,4, utf8_decode($dato_venta->nombre_users),0,0,'L',false);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(22,4, $dato_venta->id_formas_pago == 1 ? "Pago:" : utf8_decode("Total de cuotas:"),0,0,'L',false);
            $pdf->SetFont('Helvetica','',8);
            if ($dato_venta->id_formas_pago == 2){
                $dato_cuotas = $this->venta->listar_cuotas($id);
                $formas_de_pago_mensaje  = count($dato_cuotas);
            }
            $pdf->Cell(42,4,  utf8_decode($formas_de_pago_mensaje),0,1,'L',false);
            $pdf->Ln(1);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(22,4,"$dnni:",0,0,'L');
            $pdf->SetFont('Helvetica','',8);
            $pdf->Cell(30,4, "$documento",0,0,'L',false);
            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(14,4,"Cliente:",0,0,'L');
            if($dato_venta->id_tipo_documento != 4){
                $pdf->SetFont('Helvetica','',7);
                $pdf->MultiAlignCell(115,4, utf8_decode($dato_venta->cliente_nombre),0,1,'L',false);
            }else{
                $pdf->SetFont('Helvetica','',7);
                $pdf->MultiAlignCell(115,4, utf8_decode($dato_venta->cliente_razonsocial),0,1,'L',false);
            }

            $pdf->Ln(1);

            $pdf->SetFillColor(180,180,180);
            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(16,4,utf8_decode('Dirección:'),0,0,'L');
            $pdf->SetFont('Helvetica','',8);
            $direccionCliente = isset($dato_venta->cliente_direccion) ? $dato_venta->cliente_direccion : '-';
            $pdf->MultiCell(165,4,utf8_decode($direccionCliente),0,1,'');

            $pdf->Ln(1);

            $pdf->SetFont('Helvetica','B',8);
            $pdf->Cell(26,4,"Forma de pago:",0,0,'L');
            $pdf->SetFont('Helvetica','',7);
            $pdf->Cell(14,4,utf8_decode($dato_venta->id_formas_pago == 1 ? 'CONTADO' : 'CRÉDITO'),0,1,'L');
            if ((int)$dato_venta->id_formas_pago === 2) {
                $dato_cuotas = $this->venta->listar_cuotas($id);

                $cuotasTxt = [];
                $i = 1;

                foreach ($dato_cuotas as $da) {
                    $nro = str_pad((string)$i, 3, '0', STR_PAD_LEFT);
                    $fecha = date('d-m-Y', strtotime($da->venta_cuota_fecha));
                    $importe = number_format((float)$da->venta_cuota_importe, 2, '.', '');

                    $cuotasTxt[] = "Cuota {$nro}: {$fecha} ({$dato_venta->simbolo} {$importe})";
                    $i++;
                }
                $pdf->SetFont('Helvetica', '', 6);
                $pdf->MultiAlignCell(180, 4, implode('  -  ', $cuotasTxt), 0, 1, 'L');
            }
            if ($dato_venta->tipo_documento_modificar) {

                if ($dato_venta->venta_tipo == "07") {
                    $datos = Tipo_ncredito::listar_tipo_notaC_x_codigo($dato_venta->venta_codigo_motivo_nota);
                } else {
                    $datos = Tipo_ndebito::listar_tipo_notaD_x_codigo($dato_venta->venta_codigo_motivo_nota);
                }

                $motivo = $datos->tipo_nota_descripcion ?? '-';
                $comprobanteAfectado = $dato_venta->tipo_documento_modificar == '03' ? 'BOLETA' : 'FACTURA';

                $pdf->Ln(2);

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(36, 4, utf8_decode("Comprobante afectado:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(20, 4, utf8_decode($comprobanteAfectado), 0, 0, 'L');

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(42, 4, utf8_decode("Serie del comprobante:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(18, 4, utf8_decode($dato_venta->serie_modificar ?? '-'), 0, 0, 'L');

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(46, 4, utf8_decode("Correlativo del comprobante:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(18, 4, utf8_decode($dato_venta->correlativo_modificar ?? '-'), 0, 1, 'L');

                $pdf->Ln(1);

                $pdf->SetFont('Helvetica', 'B', 8);
                $pdf->Cell(30, 4, utf8_decode("Motivo de la nota:"), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(150, 4, utf8_decode($motivo), 0, 1, 'L');
            }
            $pdf->Ln(3);
            //COLUMNAS
            $pdf->Cell(180,0,'','T',1,'R');
            $pdf->Ln(3);
            $pdf->SetFont('Helvetica','B',7);
            $pdf->Cell(8, 10, 'ITEM', 1,'','C',1);
            $pdf->Cell(10, 10, 'CANT',1,0,'C',1);
            $pdf->Cell(105, 10, utf8_decode('DESCRIPCIÓN'), 1,'','C',1);
            $pdf->Cell(20, 10, 'V.U.',1,0,'C',1);
            $pdf->Cell(20, 10, 'P.U.',1,0,'C',1);
            $pdf->Cell(17, 10, 'P.VENTA',1,1,'C',1);

            $pdf->SetWidths(array(8,10,105,20,20,17));
            $aa = 1;
            $filas_tot = 0;
            foreach ($detalle_venta as $f){
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Row(array($aa,$f->venta_detalle_cantidad, utf8_decode($f->venta_detalle_nombre_producto),  number_format(round("$f->venta_detalle_valor_unitario",2), 2, '.', ' '),  number_format(round("$f->venta_detalle_precio_unitario",2), 2, '.', ' '),number_format(round("$f->venta_detalle_importe_total",2), 2, '.', ' ')));
                $aa++;
            }
            $pdf->Ln(7);
            $pdf->Cell(80,3,'','T',0,'R');
            $pdf->Cell(60,0,'',0,0,'L');
            $pdf->Cell(40,3,'','T',1,'R');
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->Cell(70, 3, "$importe_letra", 0,0,'L');
            if ($dato_venta->venta_tipo != "20") {
                $pdf->Image("$ruta_qr", '8', $pdf->GetY() + 4, '20', '20', '', '');
            }
            $pdf->Ln(8);
            if($dato_venta->venta_tipo != "20"){
                $pdf->Cell(80,1,'BIENES TRANSFERIDOS PARA SU ',0,0,'R');
            }else{
                $pdf->Cell(80,1,'ESTE NO ES UN COMPROBANTE',0,0,'R');
            }

            $pdf->Cell(100, 1, "Op.Grat: $dato_venta->simbolo $dato_venta->venta_totalgratuita", 0,1,'R');
            $pdf->Ln(3);
            if($dato_venta->venta_tipo != "20"){
                $pdf->Cell(80,1,'CONSUMO EN EL TERRITORIO NACIONAL',0,0,'R');
            }else{
                $pdf->Cell(80,1,'VALIDO PARA SUNAT SI REQUIERE UNA',0,0,'R');
            }
            $pdf->Cell(100, 1, "Op.Exon: $dato_venta->simbolo $dato_venta->venta_totalexonerada", 0,1,'R');
            $pdf->Ln(3);
            if($dato_venta->venta_tipo != "20"){
                $pdf->Cell(80,1,'CONFORME A LA NORMATIVA VIGENTE',0,0,'R');
            }else{
                $pdf->Cell(80,1,utf8_decode("BOLETA O FACTURA, SOLICÍTALO"),0,0,'R');
            }
            $pdf->Cell(100, 1, "Op.Inaf: $dato_venta->simbolo $dato_venta->venta_totalinafecta", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "Op.Grav: $dato_venta->simbolo $dato_venta->venta_totalgravada", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "IGV: $dato_venta->simbolo $dato_venta->venta_totaligv", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "Pago con: $dato_venta->simbolo $dato_venta->venta_pago_cliente", 0,1,'R');
            $pdf->Ln(3);
            $pdf->Cell(180, 1, "Vuelto : $dato_venta->simbolo $dato_venta->venta_vuelto", 0,1,'R');
            $pdf->Ln(3);

            $pdf->Ln(5);
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell(70, 0, utf8_decode('ASSU Ventas | Tu aliado en facturación electrónica.'), 0, 0, 'L');
            $pdf->SetFont('Helvetica', 'B', 9);
            $pdf->Cell(110, 1, "TOTAL: $dato_venta->simbolo $dato_venta->venta_total", 0,'1','R');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Ln(3);
            $pdf->Cell(60,0,'',0,1,'L');
            $pdf->Ln(3);
            $pdf->Cell(80,3,'','T',0,'R');
            $pdf->Cell(60,0,'',0,0,'L');
            $pdf->Cell(40,3,'','T',1,'R');

            $dir = storage_path('app/comprobantes_ventas');
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $pdfFilePath = $dir . DIRECTORY_SEPARATOR . $serie_correlativo . '-' . date('Y-m-d') . '.pdf';
            $pdf->Output($pdfFilePath, 'F');
            return $pdfFilePath;

        }
    }
    public function imprimir_ticketera_venta(){
        $id = $_GET['venta_id'];
        $id_venta = (int)$id;
        if($id_venta){
            $guardar_localmente = true;
            $ruta_guardado = "";
            $dato_venta = $this->venta->listar_venta_x_id_pdf($id_venta);
            $detalle_venta = $this->venta->listar_venta_detalle_x_id_venta_pdf($id_venta);
            $formas_de_pago = Ventas_detalle_pago::listar_formas_x_idventa($id_venta);
            $formas_de_pago_mensaje = collect($formas_de_pago)->pluck('tipo_pago_nombre')->filter()->implode(' - ');
            $ruta_qr = $this->general->generar_qr($dato_venta->id_venta);

            if ($dato_venta->venta_tipo == "03") {
                $tipo_comprobante = "BOLETA DE VENTA ELECTRÓNICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $documento = "DNI:                            $dato_venta->cliente_numero";
            } else if ($dato_venta->venta_tipo == "01") {
                $tipo_comprobante = "FACTURA DE VENTA ELECTRÓNICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $documento = "RUC:                          $dato_venta->cliente_numero";
            } else if ($dato_venta->venta_tipo == "07") {
                $tipo_comprobante = "NOTA DE CRÉDITO DE VENTA ELECTRÓNICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $documento = "DOCUMENTO: $dato_venta->cliente_numero";
            } else if($dato_venta->venta_tipo == "08") {
                $tipo_comprobante = "NOTA DE DÉBITO DE VENTA ELECTRÓNICA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $documento = "DOCUMENTO: $dato_venta->cliente_numero";
            }else if($dato_venta->venta_tipo == "20") {
                $tipo_comprobante = "NOTA DE VENTA";
                $serie_correlativo = $dato_venta->venta_serie."-".$dato_venta->venta_correlativo;
                $documento = "DOCUMENTO: $dato_venta->cliente_numero";
            }
            $da = new NumeroALetras();
            $importe_letra = $da->toInvoice($dato_venta->venta_total,'2','soles');

            // ── Medición de altura dinámica ──────────────────────
            $wDesc   = 30;
            $hLine   = 4;
            $hHeaderFijo  = 100;
            $hTablaHeader = 8;
            $hTotales     = 60;
            $hQRyFooter   = 50;
            $hExtra       = 30;

            $tmp = new PDFBufeo('P', 'mm', [80, 300]);
            $tmp->SetFont('Helvetica', '', 7);
            $hDetalle = 0;
            foreach ($detalle_venta as $f) {
                $lineas    = $tmp->NbLines($wDesc, utf8_decode($f->venta_detalle_nombre_producto));
                $hDetalle += max(1, $lineas) * $hLine;
            }
            $altura_total = $hHeaderFijo + $hTablaHeader + $hDetalle + $hTotales + $hQRyFooter + $hExtra;
            $altura_total = max(180, min($altura_total, 3000));

            // ── Inicializar PDF ───────────────────────────────────
            $pdf = new PDFBufeo('P', 'mm', [80, $altura_total]);
            $pdf->SetMargins(10, 5, 10);
            $pdf->SetAutoPageBreak(false);
            $pdf->AddPage();

            // ── Logo ──────────────────────────────────────────────
            if (file_exists($dato_venta->empresa_foto_ticket)) {
                $pdf->Image(
                    $dato_venta->empresa_foto_ticket,
                    config('services.pdf.izq_logo_ticket'), 5,
                    config('services.pdf.ancho'), config('services.pdf.alto')
                );
            }
            $pdf->Ln(22);

            // ── Razón social y datos empresa ──────────────────────
            $pdf->SetFont('Helvetica', 'B', 9);
            $pdf->Cell(60, 5, utf8_decode($dato_venta->empresa_razon_social), 0, 1, 'C');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell(60, 4, 'RUC: ' . $dato_venta->empresa_ruc, 0, 1, 'C');
            $pdf->Cell(60, 4, utf8_decode($dato_venta->empresa_domiciliofiscal), 0, 1, 'C');
            $pdf->Cell(60, 4, utf8_decode($dato_venta->ubigeo_distrito . ', ' . $dato_venta->ubigeo_provincia . ', ' . $dato_venta->ubigeo_departamento), 0, 1, 'C');

            // ── Separador ─────────────────────────────────────────
            $pdf->Ln(2);
            $pdf->SetDrawColor(40, 40, 40);
            $pdf->SetLineWidth(0.5);
            $pdf->Line(10, $pdf->GetY(), 70, $pdf->GetY());
            $pdf->Ln(3);

            // ── Tipo y número de comprobante ──────────────────────
            $pdf->SetFont('Helvetica', 'B', 9);
            $pdf->Cell(60, 5, utf8_decode($tipo_comprobante), 0, 1, 'C');
            $pdf->Cell(60, 5, $serie_correlativo, 0, 1, 'C');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell(60, 4, 'Fecha: ' . date('d/m/Y H:i', strtotime($dato_venta->venta_fecha)), 0, 1, 'C');

            // ── Separador ─────────────────────────────────────────
            $pdf->Ln(2);
            $pdf->Line(10, $pdf->GetY(), 70, $pdf->GetY());
            $pdf->Ln(3);

            // ── Datos del cliente ─────────────────────────────────
            $clienteNombre = ($dato_venta->id_tipo_documento == 4)
                ? $dato_venta->cliente_razonsocial
                : $dato_venta->cliente_nombre;
            $docLabel = ($dato_venta->id_tipo_documento == 4) ? 'RUC' : 'DOC';

            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->Cell(17, 4, utf8_decode('Cliente:'), 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->MultiCell(43, 4, utf8_decode($clienteNombre), 0, 'L');

            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->Cell(17, 4, $docLabel . ':', 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell(43, 4, $dato_venta->cliente_numero, 0, 1, 'L');

            if ($dato_venta->cliente_direccion) {
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->Cell(17, 4, utf8_decode('Dirección:'), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->MultiCell(43, 4, utf8_decode($dato_venta->cliente_direccion), 0, 'L');
            }

            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->Cell(17, 4, utf8_decode('F. Pago:'), 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Cell(43, 4, utf8_decode($dato_venta->id_formas_pago == 1 ? 'Contado' : 'Crédito'), 0, 1, 'L');

            if ($dato_venta->id_formas_pago == 1 && $formas_de_pago_mensaje) {
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->Cell(17, 4, utf8_decode('Medio:'), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(43, 4, utf8_decode($formas_de_pago_mensaje), 0, 1, 'L');
            } elseif ($dato_venta->id_formas_pago != 1) {
                $dato_cuotas = $this->venta->listar_cuotas($id);
                $pdf->SetFont('Helvetica', 'B', 7);
                $pdf->Cell(17, 4, utf8_decode('Cuotas:'), 0, 0, 'L');
                $pdf->SetFont('Helvetica', '', 7);
                $pdf->Cell(43, 4, (string)count($dato_cuotas), 0, 1, 'L');
            }

            // ── Separador ─────────────────────────────────────────
            $pdf->Ln(2);
            $pdf->Line(10, $pdf->GetY(), 70, $pdf->GetY());
            $pdf->Ln(3);

            // ── Encabezado de tabla ───────────────────────────────
            $pdf->SetFillColor(30, 30, 30);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetFont('Helvetica', 'B', 7);
            $pdf->Cell(30, 7, utf8_decode('Descripción'), 0, 0, 'C', true);
            $pdf->Cell(8,  7, 'Cant.',  0, 0, 'C', true);
            $pdf->Cell(11, 7, 'Precio', 0, 0, 'C', true);
            $pdf->Cell(11, 7, 'Total',  0, 1, 'C', true);
            $pdf->SetTextColor(0, 0, 0);
            $pdf->SetFillColor(255, 255, 255);

            // ── Filas de detalle ──────────────────────────────────
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->SetWidths([30, 8, 11, 11]);
            foreach ($detalle_venta as $f) {
                $pdf->Row([
                    utf8_decode($f->venta_detalle_nombre_producto),
                    number_format((float)$f->venta_detalle_cantidad, 2, '.', ''),
                    number_format(round((float)$f->venta_detalle_precio_unitario, 2), 2, '.', ''),
                    number_format(round((float)$f->venta_detalle_importe_total,   2), 2, '.', ''),
                ]);
            }

            // ── Línea inferior tabla ──────────────────────────────
            $pdf->Ln(2);
            $pdf->SetLineWidth(0.5);
            $pdf->Line(10, $pdf->GetY(), 70, $pdf->GetY());
            $pdf->Ln(3);

            // ── Totales (ancho completo) ──────────────────────────
            $pdf->SetFont('Helvetica', '', 7);
            $lineH = 4;
            $lW    = 33;
            $vW    = 27;

            $rows = [];
            if ((float)$dato_venta->venta_totalgratuita  > 0) $rows[] = [utf8_decode('Op. Gratuita'),  $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_totalgratuita,  2)];
            if ((float)$dato_venta->venta_totalexonerada > 0) $rows[] = [utf8_decode('Op. Exonerada'), $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_totalexonerada, 2)];
            if ((float)$dato_venta->venta_totalinafecta  > 0) $rows[] = [utf8_decode('Op. Inafecta'),  $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_totalinafecta,  2)];
            if ((float)$dato_venta->venta_totalgravada   > 0) $rows[] = [utf8_decode('Op. Gravada'),   $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_totalgravada,   2)];
            if ((float)$dato_venta->venta_totaligv       > 0) $rows[] = ['IGV (18%)',                  $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_totaligv,       2)];
            $rows[] = [utf8_decode('Pago recibido'), $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_pago_cliente, 2)];
            $rows[] = [utf8_decode('Vuelto'),        $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_vuelto,       2)];

            foreach ($rows as $row) {
                $pdf->Cell($lW, $lineH, $row[0] . ':', 0, 0, 'R');
                $pdf->Cell($vW, $lineH, $row[1],        0, 1, 'R');
            }

            $pdf->Ln(1);
            $pdf->SetLineWidth(0.3);
            $pdf->Line(10, $pdf->GetY(), 70, $pdf->GetY());
            $pdf->Ln(2);
            $pdf->SetFont('Helvetica', 'B', 10);
            $pdf->Cell($lW, 6, 'TOTAL:', 0, 0, 'R');
            $pdf->Cell($vW, 6, $dato_venta->simbolo . ' ' . number_format((float)$dato_venta->venta_total, 2), 0, 1, 'R');
            $pdf->SetFont('Helvetica', 'I', 6.5);
            $pdf->MultiCell(60, 4, utf8_decode(strtoupper($importe_letra)), 0, 'R');
            $pdf->Ln(2);

            // ── QR centrado debajo de los totales ─────────────────
            if ($dato_venta->venta_tipo != '20') {
                $wQR = 25;
                $xQR = (80 - $wQR) / 2;
                $pdf->Image($ruta_qr, $xQR, $pdf->GetY(), $wQR, $wQR);
                $pdf->Ln($wQR + 2);
            }

            // ── Separador y pie ───────────────────────────────────
            $pdf->SetLineWidth(0.5);
            $pdf->Line(10, $pdf->GetY(), 70, $pdf->GetY());
            $pdf->Ln(4);

            $pdf->SetFont('Helvetica', 'B', 7.5);
            $pdf->Cell(60, 5, utf8_decode('¡Gracias por su compra!'), 0, 1, 'C');
            $pdf->SetFont('Helvetica', '', 6.5);
            $pdf->Cell(60, 4, utf8_decode('Este comprobante es válido electrónicamente.'), 0, 1, 'C');

            // ── Salida ────────────────────────────────────────────
            $ruta_guardado = 'comprobantes/' . $serie_correlativo . '-' . date('Y-m-d') . '.pdf';
            $pdf->Output('I', $ruta_guardado);
            exit;

        }


    }
    public function enviarComprobanteporCorreo( Request $request){
        // Código de error general
        $result = 2;
        // Mensaje a devolver en caso de hacer consulta por app
        $message = 'OK';
        try {

            $validator = Validator::make($request->all(), [
                'correoDestino' => 'required|email',
                'id_venta'=>'required'// Ajusta el nombre del parámetro según tus necesidades
            ]);

            if ($validator->fails()) {
                $result = 6;
                $message = "Integridad de datos fallida. Alguno(s) de los parámetros se están enviando de manera incorrecta";
            } else {

                $venta = $this->venta->listar_venta_x_id($request->id_venta);
                if ($venta){
                    $empresa = DB::table('empresa')->where('id_empresa','=',1)->first();
                    $comprobante = $this->imprimir_ticket_pdf_local($request->id_venta);
                    $rutaXML = null;
                    $rutaCDR = null;
                    if (file_exists($venta->venta_rutaXML)){
                        $rutaXML = $venta->venta_rutaXML;
                    }
                    if (file_exists($venta->venta_rutaCDR)){
                        $rutaCDR = $venta->venta_rutaCDR;
                    }
                    $correo_corpo = $empresa->empresa_correo;
                    $envio = Mail::to(strtolower($request->correoDestino))->send(new ComprobanteCorreo($comprobante,$correo_corpo,$rutaXML,$rutaCDR));
                    if($envio){
                        $result = 1;
                        $message = "Envio del comprobante fue existo";
                    }else{
                        $result = 2;
                        $message = "Ocurrio un erro al envio del comprobante";
                    }
                }else{
                    $result = 2;
                    $message = "No se encontro información de la venta.";
                }
            }

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
        }
        return response()->json(["result" => ["code" => $result, "message" => $message]]);

    }

    public function imprimirPdfReporteHistorialNotasVenta(Request $request)
    {
        try {
            $desde      = $request->desde      ?? null;
            $hasta      = $request->hasta      ?? null;
            $idCliente  = $request->cliente    ?? null;
            $idSucursal = $request->idSucursal ?? null;
            $idEmpresa  = $request->idEmpresa  ?? null;

            // ── Misma consulta que el Livewire ────────────────────
            $query = DB::table('ventas as v')
                ->select(
                    'v.*',
                    'mo.simbolo',
                    'u.nombre_users',
                    'c.id_tipo_documento',
                    'c.cliente_nombre',
                    'c.cliente_razonsocial',
                    'c.cliente_numero'
                )
                ->join('clientes as c', 'v.id_clientes', '=', 'c.id_clientes')
                ->join('monedas as mo',  'v.id_moneda',   '=', 'mo.id_moneda')
                ->join('users as u',     'v.id_users',    '=', 'u.id_users')
                ->where('v.venta_tipo', '=', '20');

            if ($desde && $hasta) {
                $query->whereBetween(DB::raw('DATE(v.venta_fecha)'), [$desde, $hasta]);
            }
            if ($idCliente) {
                $query->where('v.id_clientes', $idCliente);
            }
            if ($idSucursal) {
                $query->where('v.id_sucursal', $idSucursal);
            } elseif ($idEmpresa) {
                $query->whereIn('v.id_sucursal', function ($sub) use ($idEmpresa) {
                    $sub->select('id_sucursal')->from('sucursals')
                        ->where('id_empresa', $idEmpresa)
                        ->where('sucursal_estado', 1)
                        ->whereNull('deleted_at');
                });
            }

            $registros = $query->orderByDesc('v.venta_fecha')->get();

            // ── Datos para el encabezado ──────────────────────────
            $nombreCliente = 'TODOS';
            if ($idCliente) {
                $cli = DB::table('clientes')->where('id_clientes', $idCliente)->first();
                if ($cli) {
                    $nombreCliente = $cli->cliente_razonsocial ?? $cli->cliente_nombre;
                }
            }

            $fechaDesde = $desde ? date('d/m/Y', strtotime($desde)) : '-';
            $fechaHasta = $hasta ? date('d/m/Y', strtotime($hasta)) : '-';

            // ── FPDF — A4 Vertical ────────────────────────────────
            // Ancho útil: 210mm - 10mm(izq) - 10mm(der) = 190mm
            $pdf = new PDFBufeo('P', 'mm', 'A4');
            $pdf->AddPage();

            $pdf->Ln(2);

            // Título
            $pdf->SetFont('Helvetica', 'B', 12);
            $pdf->Cell(180, 8, utf8_decode('Reporte de Notas de Venta'), 0, 1, 'C', 0);
            $pdf->Ln(4);
            $pdf->Cell(180, 0, '', 'T', 1, 'R');
            $pdf->Ln(3);

            // Filtros
            $pdf->SetFont('Helvetica', 'B', 8);
            $pdf->Cell(20, 4, utf8_decode('Cliente: '), 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->Cell(100, 4, utf8_decode($nombreCliente), 0, 1, 'L');

            $pdf->SetFont('Helvetica', 'B', 8);
            $pdf->Cell(20, 4, utf8_decode('Desde: '), 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->Cell(50, 4, utf8_decode($fechaDesde), 0, 0, 'L');

            $pdf->SetFont('Helvetica', 'B', 8);
            $pdf->Cell(20, 4, utf8_decode('Hasta: '), 0, 0, 'L');
            $pdf->SetFont('Helvetica', '', 8);
            $pdf->Cell(50, 4, utf8_decode($fechaHasta), 0, 1, 'L');

            $pdf->Ln(3);
            $pdf->Cell(180, 0, '', 'T', 1, 'R');
            $pdf->Ln(3);

            // ── Encabezado de tabla ───────────────────────────────
            // Total anchos = 8+18+22+20+42+30+22+18+10 = 190mm
            $pdf->SetFont('Helvetica', 'B', 6);
            $pdf->SetFillColor(33, 44, 62);
            $pdf->SetTextColor(255, 255, 255);

            $pdf->Cell(8,  10, utf8_decode('N°'),                 1, 0, 'C', 1);
            $pdf->Cell(18, 10, utf8_decode('Fecha'),              1, 0, 'C', 1);
            $pdf->Cell(22, 10, utf8_decode('Serie-Correlativo'),  1, 0, 'C', 1);
            $pdf->Cell(20, 10, utf8_decode('N° Documento'),       1, 0, 'C', 1);
            $pdf->Cell(42, 10, utf8_decode('Cliente'),            1, 0, 'C', 1);
            $pdf->Cell(30, 10, utf8_decode('Registrado Por'),     1, 0, 'C', 1);
            $pdf->Cell(22, 10, utf8_decode('Total'),              1, 0, 'C', 1);
            $pdf->Cell(18, 10, utf8_decode('Estado'),             1, 1, 'C', 1);

            $pdf->SetWidths([8, 18, 22, 20, 42, 30, 22, 18]);

            // ── Filas de datos ────────────────────────────────────
            $pdf->SetFont('Helvetica', '', 6);
            $pdf->SetTextColor(0, 0, 0);

            $numero = 1;
            foreach ($registros as $reg) {

                $fechaEmision     = !empty($reg->venta_fecha)
                    ? date('d/m/Y H:i', strtotime($reg->venta_fecha))
                    : '';
                $serieCorrelativo = $reg->venta_serie . '-' . $reg->venta_correlativo;
                $cliente          = $reg->id_tipo_documento == 4
                    ? $reg->cliente_razonsocial
                    : $reg->cliente_nombre;
                $estado           = $reg->anulado_sunat == 1 ? 'Anulado' : 'Vigente';
                $total            = $reg->simbolo . number_format($reg->venta_total, 2);

                // Resaltar anulados en rojo claro (igual que la vista: #efa6ad)
                if ($reg->anulado_sunat == 1) {
                    $pdf->SetFillColor(239, 166, 173);
                } else {
                    $pdf->SetFillColor(255, 255, 255);
                }

                $pdf->Row([
                    $numero,
                    utf8_decode($fechaEmision),
                    utf8_decode($serieCorrelativo),
                    utf8_decode($reg->cliente_numero),
                    utf8_decode($cliente),
                    utf8_decode($reg->nombre_users),
                    utf8_decode($total),
                    utf8_decode($estado),
                ]);

                $numero++;
            }

            $pdf->Ln(7);
            $pdf->Output('', 'Notas_Venta_' . date('Ymd_His') . '.pdf');
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            return redirect()->route('intranet')->with('error', 'Ocurrió un error al generar el PDF.');
        }
    }
    public function imprimirExcelHistorialNotasDeVenta(Request $request)
    {
        try {
            $desde      = $request->desde      ?? null;
            $hasta      = $request->hasta      ?? null;
            $idCliente  = $request->cliente    ?? null;
            $idSucursal = $request->idSucursal ?? null;
            $idEmpresa  = $request->idEmpresa  ?? null;

            // ── Misma consulta que el Livewire ────────────────────
            $query = DB::table('ventas as v')
                ->select(
                    'v.*',
                    'mo.simbolo',
                    'u.nombre_users',
                    'c.id_tipo_documento',
                    'c.cliente_nombre',
                    'c.cliente_razonsocial',
                    'c.cliente_numero'
                )
                ->join('clientes as c', 'v.id_clientes', '=', 'c.id_clientes')
                ->join('monedas as mo',  'v.id_moneda',   '=', 'mo.id_moneda')
                ->join('users as u',     'v.id_users',    '=', 'u.id_users')
                ->where('v.venta_tipo', '=', '20');

            if ($desde && $hasta) {
                $query->whereBetween(DB::raw('DATE(v.venta_fecha)'), [$desde, $hasta]);
            }
            if ($idCliente) {
                $query->where('v.id_clientes', $idCliente);
            }
            if ($idSucursal) {
                $query->where('v.id_sucursal', $idSucursal);
            } elseif ($idEmpresa) {
                $query->whereIn('v.id_sucursal', function ($sub) use ($idEmpresa) {
                    $sub->select('id_sucursal')->from('sucursals')
                        ->where('id_empresa', $idEmpresa)
                        ->where('sucursal_estado', 1)
                        ->whereNull('deleted_at');
                });
            }

            $registros = $query->orderByDesc('v.venta_fecha')->get();

            // ── Datos para el encabezado ──────────────────────────
            $nombreCliente = 'TODOS';
            if ($idCliente) {
                $cli = DB::table('clientes')->where('id_clientes', $idCliente)->first();
                if ($cli) {
                    $nombreCliente = $cli->cliente_razonsocial ?? $cli->cliente_nombre;
                }
            }

            $fechaDesde = $desde ? date('d/m/Y', strtotime($desde)) : '-';
            $fechaHasta = $hasta ? date('d/m/Y', strtotime($hasta)) : '-';

            // ── PhpSpreadsheet ────────────────────────────────────
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle('Notas de Venta');

            // Estilos reutilizables
            $estiloTitulo = [
                'font'      => ['bold' => true, 'size' => 14, 'color' => ['argb' => 'FF1F2C3E'], 'name' => 'Arial'],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
            ];
            $estiloEtiqueta = [
                'font' => ['bold' => true, 'size' => 9, 'name' => 'Arial'],
            ];
            $estiloValor = [
                'font' => ['size' => 9, 'name' => 'Arial'],
            ];
            $estiloEncabezadoTabla = [
                'font'      => ['bold' => true, 'color' => ['argb' => 'FFFFFFFF'], 'size' => 8, 'name' => 'Arial'],
                'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['argb' => 'FF212C3E']],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical'   => Alignment::VERTICAL_CENTER,
                    'wrapText'   => true,
                ],
                'borders' => ['allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color'       => ['argb' => 'FFFFFFFF'],
                ]],
            ];

            // ── Fila 1: Título ────────────────────────────────────
            $sheet->mergeCells('A1:H1');
            $sheet->setCellValue('A1', 'Reporte de Notas de Venta');
            $sheet->getStyle('A1')->applyFromArray($estiloTitulo);
            $sheet->getRowDimension(1)->setRowHeight(22);

            // ── Filas 2-3: Filtros aplicados ──────────────────────
            $filtros = [
                ['Cliente:', $nombreCliente, 'Desde:', $fechaDesde],
                ['Hasta:',   $fechaHasta,    'Total registros:', $registros->count()],
            ];

            $fila = 2;
            foreach ($filtros as $row) {
                $sheet->setCellValue("A{$fila}", $row[0]);
                $sheet->setCellValue("B{$fila}", $row[1]);
                $sheet->setCellValue("E{$fila}", $row[2]);
                $sheet->setCellValue("F{$fila}", $row[3]);
                $sheet->getStyle("A{$fila}")->applyFromArray($estiloEtiqueta);
                $sheet->getStyle("B{$fila}")->applyFromArray($estiloValor);
                $sheet->getStyle("E{$fila}")->applyFromArray($estiloEtiqueta);
                $sheet->getStyle("F{$fila}")->applyFromArray($estiloValor);
                $fila++;
            }

            // ── Fila 5: Encabezados de la tabla ───────────────────
            $filaEncabezado = 5;
            $encabezados    = ['#', 'Fecha de Emisión', 'Serie-Correlativo', 'N° Documento', 'Cliente', 'Registrado Por', 'Total', 'Estado'];
            $columnas       = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

            foreach ($columnas as $i => $col) {
                $sheet->setCellValue("{$col}{$filaEncabezado}", $encabezados[$i]);
            }
            $sheet->getStyle("A{$filaEncabezado}:H{$filaEncabezado}")->applyFromArray($estiloEncabezadoTabla);
            $sheet->getRowDimension($filaEncabezado)->setRowHeight(24);

            // ── Filas de datos ─────────────────────────────────────
            $filaData = 6;
            $numero   = 1;

            foreach ($registros as $reg) {
                $fechaEmision     = !empty($reg->venta_fecha)
                    ? date('d/m/Y H:i:s', strtotime($reg->venta_fecha))
                    : '';
                $serieCorrelativo = $reg->venta_serie . '-' . $reg->venta_correlativo;
                $cliente          = $reg->id_tipo_documento == 4
                    ? $reg->cliente_razonsocial
                    : $reg->cliente_nombre;
                $estado           = $reg->anulado_sunat == 1 ? 'Anulado' : 'Vigente';
                $total            = $reg->simbolo . number_format($reg->venta_total, 2);

                $sheet->setCellValue("A{$filaData}", $numero);
                $sheet->setCellValue("B{$filaData}", $fechaEmision);
                $sheet->setCellValue("C{$filaData}", $serieCorrelativo);
                $sheet->setCellValue("D{$filaData}", $reg->cliente_numero);
                $sheet->setCellValue("E{$filaData}", $cliente);
                $sheet->setCellValue("F{$filaData}", $reg->nombre_users);
                $sheet->setCellValue("G{$filaData}", $total);
                $sheet->setCellValue("H{$filaData}", $estado);

                // Anulados con fondo rojo claro (igual que la vista)
                if ($reg->anulado_sunat == 1) {
                    $sheet->getStyle("A{$filaData}:H{$filaData}")->applyFromArray([
                        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['argb' => 'FFefa6ad']],
                    ]);
                } elseif ($filaData % 2 == 0) {
                    // Fila alternada gris claro
                    $sheet->getStyle("A{$filaData}:H{$filaData}")->applyFromArray([
                        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['argb' => 'FFF2F2F2']],
                    ]);
                }

                // Borde y alineación vertical en todas las filas
                $sheet->getStyle("A{$filaData}:H{$filaData}")->applyFromArray([
                    'borders'   => ['allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color'       => ['argb' => 'FFD0D0D0'],
                    ]],
                    'alignment' => ['vertical' => Alignment::VERTICAL_CENTER],
                ]);

                $filaData++;
                $numero++;
            }

            // ── Ancho de columnas ──────────────────────────────────
            $anchos = ['A' => 5, 'B' => 20, 'C' => 18, 'D' => 14, 'E' => 35, 'F' => 22, 'G' => 13, 'H' => 10];
            foreach ($anchos as $col => $ancho) {
                $sheet->getColumnDimension($col)->setWidth($ancho);
            }

            // ── Descargar ──────────────────────────────────────────
            $nombreArchivo = 'Notas_Venta_' . date('Ymd_His') . '.xlsx';

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header("Content-Disposition: attachment; filename=\"{$nombreArchivo}\"");
            header('Cache-Control: max-age=0');

            $writer = new Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;

        } catch (\Exception $e) {
            $this->logs->insertarLog($e);
            return redirect()->route('intranet')->with('error', 'Ocurrió un error al generar el Excel.');
        }
    }
    public function clientes()
    {
        try {
            $opciones = $this->submenu->optiones_por_vista("clientes");
            return view('gestionventas.clientes',compact('opciones'));
        }catch (\Exception $e){
            $this->logs->insertarLog($e);
        }
    }

    public function pedidos()
    {
        abort_if(!auth()->user()->can('pedidos.listar'), 403);
        $opciones = $this->submenu->optiones_por_vista('pedidos');
        return view('gestion-ventas.pedidos', compact('opciones'));
    }

    public function caja_pedidos()
    {
        abort_if(!auth()->user()->can('caja_pedidos.listar'), 403);
        $opciones = $this->submenu->optiones_por_vista('caja_pedidos');
        return view('gestion-ventas.caja', compact('opciones'));
    }

    public function despacho()
    {
        abort_if(!auth()->user()->can('despacho.listar'), 403);
        $opciones = $this->submenu->optiones_por_vista('despacho');
        return view('gestion-ventas.despacho', compact('opciones'));
    }

    public function imprimir_ticket_pedido(Request $request)
    {
        $id         = (int) $request->get('data');
        $id_pedido  = $id;

        if (!$id_pedido) {
            abort(404);
        }

        $pedido = DB::table('pedidos as p')
            ->leftJoin('tiendas as t', 't.id_tienda', '=', 'p.id_tienda')
            ->leftJoin('empresa as e', 'e.id_empresa', '=', 'p.id_empresa')
            ->where('p.id_pedido', $id_pedido)
            ->select(
                'p.*',
                't.tienda_nombre',
                'e.empresa_razon_social',
                'e.empresa_nombrecomercial',
                'e.empresa_domiciliofiscal',
                'e.empresa_ruc',
                'e.empresa_telefono1',
                'e.empresa_foto_ticket'
            )
            ->first();

        if (!$pedido) {
            abort(404);
        }

        $detalle = DB::table('pedidos_detalle as pd')
            ->join('productos as p', 'p.id_pro', '=', 'pd.id_pro')
            ->where('pd.id_pedido', $id_pedido)
            ->where('pd.pedido_deta_estado', 1)
            ->select('pd.*', 'p.pro_codigo')
            ->get();

        $empresa_nombre = $pedido->empresa_nombrecomercial ?: $pedido->empresa_razon_social;

        // ====== CONFIG TICKET 80mm ======
        $ticketW  = 80;
        $left     = 5;
        $right    = 5;
        $usableW  = $ticketW - $left - $right;
        $hLine    = 4;

        $hHeader  = 55;
        $hCliente = 25;
        $hTabla   = 14;
        $hTotales = 20;
        $hFooter  = 15;
        $hExtra   = 10;

        // Calcular altura dinámica
        $tmp = new PDFBufeo('P', 'mm', [80, 300]);
        $tmp->SetFont('Helvetica', '', 7);
        $wItem = 40;
        $hDetalle = 0;
        foreach ($detalle as $f) {
            $txt    = utf8_decode($f->pedido_deta_nombre);
            $lineas = $tmp->NbLines($wItem, $txt);
            $hDetalle += max(1, $lineas) * $hLine;
        }

        $altura_total = $hHeader + $hCliente + $hTabla + $hDetalle + $hTotales + $hFooter + $hExtra;
        $altura_total = max(150, min($altura_total, 3000));

        $pdf = new PDFBufeo('P', 'mm', [$ticketW, $altura_total]);
        $pdf->SetMargins($left, 5, $right);
        $pdf->SetAutoPageBreak(false);
        $pdf->AddPage();

        // Logotipo
        if ($pedido->empresa_foto_ticket && file_exists($pedido->empresa_foto_ticket)) {
            $pdf->Image($pedido->empresa_foto_ticket, config('services.pdf.izq_logo_ticket', 20), 5, 20, 20);
        }
        $pdf->Ln(22);

        // Nombre empresa
        $pdf->SetFont('Helvetica', 'B', 8);
        $pdf->Cell($usableW, 4, utf8_decode($empresa_nombre), 0, 1, 'C');
        $pdf->SetFont('Helvetica', '', 7);
        $pdf->Cell($usableW, 4, "RUC {$pedido->empresa_ruc}", 0, 1, 'C');
        $pdf->Cell($usableW, 4, utf8_decode($pedido->empresa_domiciliofiscal ?? ''), 0, 1, 'C');

        $pdf->Ln(2);
        $pdf->SetFont('Helvetica', 'B', 11);
        $pdf->Cell($usableW, 6, 'PEDIDO', 0, 1, 'C');
        $pdf->SetFont('Helvetica', 'B', 9);
        $pdf->Cell($usableW, 5, $pedido->pedido_numero, 0, 1, 'C');

        $pdf->SetFont('Helvetica', '', 7);
        $pdf->Cell($usableW, 4, date('d/m/Y H:i:s', strtotime($pedido->created_at)), 0, 1, 'C');

        $pdf->Ln(2);
        $pdf->Cell($usableW, 0, '', 'T', 1, 'C');
        $pdf->Ln(2);

        // Datos del cliente
        $pdf->SetFont('Helvetica', '', 7);
        if ($pedido->pedido_cliente_nombre) {
            $pdf->MultiCell($usableW, 4, utf8_decode("Cliente: {$pedido->pedido_cliente_nombre}"), 0, 'L');
        }
        if ($pedido->pedido_cliente_doc) {
            $pdf->Cell($usableW, 4, "Doc: {$pedido->pedido_cliente_doc}", 0, 1, 'L');
        }
        if ($pedido->tienda_nombre) {
            $pdf->Cell($usableW, 4, utf8_decode("Tienda: {$pedido->tienda_nombre}"), 0, 1, 'L');
        }
        if ($pedido->pedido_observacion) {
            $pdf->MultiCell($usableW, 4, utf8_decode("Obs: {$pedido->pedido_observacion}"), 0, 'L');
        }

        $pdf->Ln(2);
        $pdf->Cell($usableW, 0, '', 'T', 1, 'C');
        $pdf->Ln(2);

        // Encabezado tabla
        $pdf->SetFont('Helvetica', 'B', 7);
        $pdf->Cell(40, 5, utf8_decode('Producto'), 1, 0, 'C');
        $pdf->Cell(10, 5, 'Cant', 1, 0, 'C');
        $pdf->Cell(10, 5, 'Precio', 1, 0, 'C');
        $pdf->Cell(10, 5, 'Total', 1, 1, 'C');

        // Productos
        $total_pedido = 0;
        $pdf->SetWidths([40, 10, 10, 10]);
        foreach ($detalle as $f) {
            $subtotal = (float) $f->pedido_deta_precio * (float) $f->pedido_deta_cantidad;
            $total_pedido += $subtotal;
            $pdf->SetFont('Helvetica', '', 7);
            $pdf->Row([
                utf8_decode($f->pedido_deta_nombre),
                number_format($f->pedido_deta_cantidad, 2),
                number_format($f->pedido_deta_precio, 2),
                number_format($subtotal, 2),
            ]);
        }

        $pdf->Ln(2);
        $pdf->Cell($usableW, 0, '', 'T', 1, 'C');
        $pdf->Ln(2);

        // Total
        $pdf->SetFont('Helvetica', 'B', 9);
        $pdf->Cell($usableW, 5, 'TOTAL: S/ ' . number_format($total_pedido, 2), 0, 1, 'R');

        $pdf->Ln(4);
        $pdf->SetFont('Helvetica', '', 7);
        $pdf->Cell($usableW, 4, utf8_decode('Gracias por su preferencia'), 0, 1, 'C');

        $pdf->Ln(3);
        $pdf->SetFont('Helvetica', '', 6);
        $pdf->Cell($usableW, 4, utf8_decode('Sistema Aquiles ERP | Bufeo TEC'), 0, 1, 'C');

        $pdf->Output('I', "Pedido-{$pedido->pedido_numero}.pdf");
        exit;
    }
}
